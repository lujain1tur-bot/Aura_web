
<?php $__env->startSection('title', 'Collection | Aura Quotes'); ?>
<?php $__env->startSection('content'); ?>
<section class="wrap content-page"><div class="page-heading"><a class="text-link" href="<?php echo e(route('collections.index')); ?>">← All collections</a><h1><?php echo e($collection->name); ?></h1><p><?php echo e($quotes->total()); ?> saved <?php echo e(Str::plural('quote',$quotes->total())); ?> · Private collection</p></div><details class="panel management-panel"><summary>Manage this collection</summary><form action="<?php echo e(route('collections.update',$collection)); ?>" method="POST" class="inline-editor"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?><?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['id' => 'name','label' => 'Collection name','hint' => '1–60 characters.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'name','label' => 'Collection name','hint' => '1–60 characters.']); ?><input id="name" name="name" required maxlength="60" value="<?php echo e(old('name',$collection->name)); ?>"> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?><button class="button">Rename</button></form><form action="<?php echo e(route('collections.destroy',$collection)); ?>" method="POST" data-confirm="Delete this collection? Its quotes will remain saved."><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="button button-danger">Delete collection</button></form></details><div class="quote-grid"><?php $__empty_1 = true; $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if (isset($component)) { $__componentOriginalff301bacf4984f77aa4bdcc81ca58cab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff301bacf4984f77aa4bdcc81ca58cab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quote-card','data' => ['quote' => $quote,'likedIds' => $likedIds,'savedIds' => $savedIds,'collection' => $collection]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quote-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['quote' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quote),'liked-ids' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($likedIds),'saved-ids' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($savedIds),'collection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($collection)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff301bacf4984f77aa4bdcc81ca58cab)): ?>
<?php $attributes = $__attributesOriginalff301bacf4984f77aa4bdcc81ca58cab; ?>
<?php unset($__attributesOriginalff301bacf4984f77aa4bdcc81ca58cab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff301bacf4984f77aa4bdcc81ca58cab)): ?>
<?php $component = $__componentOriginalff301bacf4984f77aa4bdcc81ca58cab; ?>
<?php unset($__componentOriginalff301bacf4984f77aa4bdcc81ca58cab); ?>
<?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state"><h2>A little room for inspiration.</h2><p>Open your saved quotes and organize them into this collection.</p><a class="button" href="<?php echo e(route('quotes.index',['saved'=>1])); ?>">Open saved quotes</a></div><?php endif; ?></div><?php if (isset($component)) { $__componentOriginal41032d87daf360242eb88dbda6c75ed1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41032d87daf360242eb88dbda6c75ed1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination','data' => ['paginator' => $quotes]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quotes)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $attributes = $__attributesOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $component = $__componentOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__componentOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\collections\show.blade.php ENDPATH**/ ?>