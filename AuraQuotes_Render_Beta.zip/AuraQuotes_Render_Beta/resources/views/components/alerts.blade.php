@if(session('success'))<div class="wrap"><div class="notice" role="status">{{ session('success') }}</div></div>@endif
@if($errors->any())<div class="wrap"><div class="notice notice-error" role="alert"><strong>Please check your details.</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div></div>@endif
