# AuraQuotes ready local project

## Run on this Windows computer

1. Extract AQ_Ready.zip completely into a short location, such as your Downloads folder.
2. Open the extracted AQ folder and double-click START-AURA.cmd.
3. The launcher uses your installed PHP/Laravel Herd, prepares Laravel and opens the site in your browser. Keep its window open while using the site.

PHP 8.4.1 or later is required; PHP 8.5 in Laravel Herd is supported. All Composer dependencies and local assets are included. No Composer install, npm build, manual file merge or database-server setup is required for this local package. If port 8000 is busy, the launcher selects an available port and opens its URL.

## Contents and data

This is a complete local copy derived from AQ (2).zip, with all its original file paths retained. The original local .env and SQLite bytes are preserved in the archive, including the account and content records already present in that input. No password was read, reset or displayed, and no account was deleted. This local backup is for your own computer and should not be uploaded publicly as a Render payload.

Startup runs migrations and repeatable seeders without resetting the database. Re-running setup preserves existing records. Optional command-line setup: php scripts/setup.php. Optional setup-only launcher: powershell -File .\start.ps1 -SetupOnly.

## Current features

Public quote library, account signup/login/logout, own-quote publishing/editing/deletion, likes, saves, search, category filters, official health resources, related topic links, personal interests, private collections and content reports. English and Arabic display, dark and light modes, and browser preference persistence are included. No music or mood-detection feature is added.

## Included corrections

- Signup rejects passwords above 72 bytes before hashing and shows translated guidance. The existing minimum of 8 characters and bcrypt cost 12 remain.
- Featured/library quotes retain their original source text when switching between Arabic and English, including after a reload.
- The JavaScript asset version is updated so the browser requests the corrected file.

Verification completed for the corrected source: 32 isolated signup checks, 42 language regression checks with a minimal DOM fixture, and the 38 existing isolated integration checks. These do not establish the deployed site's 3-second performance target or a full security audit.

The public Render service is separate from this local folder. Its URL does not change when deploying the update, but this local package does not automatically update it. The one-minute demo and formal performance/usability acceptance remain separate submission work.
