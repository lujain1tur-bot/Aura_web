#!/bin/sh
set -eu
cd /var/www/html

export APP_ENV="${APP_ENV:-production}"
export APP_DEBUG=false
export APP_URL="${APP_URL:-${RENDER_EXTERNAL_URL:-http://localhost:8080}}"
APP_KEY="$(php docker/runtime-key.php)"
export APP_KEY
export DB_CONNECTION="${DB_CONNECTION:-pgsql}"
export LOG_CHANNEL="${LOG_CHANNEL:-stderr}"
export SESSION_DRIVER="${SESSION_DRIVER:-database}"
export SESSION_ENCRYPT=true
export SESSION_SECURE_COOKIE="${SESSION_SECURE_COOKIE:-true}"
export CACHE_STORE="${CACHE_STORE:-database}"

if [ "$DB_CONNECTION" != pgsql ] && [ "$APP_ENV" != testing ]; then
    echo 'Use PostgreSQL for this deployment to preserve user data across restarts.' >&2
    exit 1
fi
if [ "$DB_CONNECTION" = pgsql ] && [ -z "${DB_URL:-}" ]; then
    echo 'Set DB_URL to your PostgreSQL connection string in Render Environment.' >&2
    exit 1
fi
case "${PORT:-8080}" in
    ''|*[!0-9]*) echo 'PORT must be numeric.' >&2; exit 1 ;;
esac
sed -i "s/8080/${PORT:-8080}/g" /etc/apache2/ports.conf /etc/apache2/sites-available/000-default.conf

php artisan config:clear
php artisan migrate --force
php artisan db:seed --force
php artisan config:cache
php artisan route:cache
php artisan view:cache
chown -R www-data:www-data storage bootstrap/cache
exec docker-php-entrypoint "$@"
