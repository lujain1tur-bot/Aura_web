@extends('layouts.app')
@section('title', 'A little off the path. | Aura Quotes')
@section('content')
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">404</span><h1>A little off the path.</h1><p>This page or item could not be found.</p><a class="button button-primary" href="{{ route('quotes.index') }}">Return to the library</a></div></section>
@endsection
