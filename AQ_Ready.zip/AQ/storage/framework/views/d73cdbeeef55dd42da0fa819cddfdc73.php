<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['quote','likedIds'=>[],'savedIds'=>[],'resourceCategories'=>[],'collection'=>null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['quote','likedIds'=>[],'savedIds'=>[],'resourceCategories'=>[],'collection'=>null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<article class="quote-card"><div class="quote-top"><a class="tag" href="<?php echo e(route('quotes.index',['category'=>$quote->category])); ?>"><?php echo e($quote->category); ?></a><span class="quote-mark" aria-hidden="true">“</span></div>
<blockquote><?php echo e($quote->content); ?></blockquote><div class="attribution"><span><?php echo e($quote->source_name ?: 'Community contribution'); ?></span><?php if($quote->sourceLink()): ?><a href="<?php echo e($quote->sourceLink()); ?>" target="_blank" rel="noopener noreferrer" class="source-link">Source ↗</a><?php endif; ?></div>
<div class="quote-meta"><span>By <?php echo e($quote->user?->name ?: 'Aura Quotes'); ?></span><time datetime="<?php echo e($quote->created_at?->toIso8601String()); ?>"><?php echo e($quote->created_at?->format('M j, Y')); ?></time></div>
<div class="quote-actions"><?php if(auth()->guard()->check()): ?><form action="<?php echo e(route('quotes.like',$quote)); ?>" method="POST"><?php echo csrf_field(); ?><button type="submit" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['action','active'=>in_array($quote->id,$likedIds)]); ?>" aria-pressed="<?php echo e(in_array($quote->id,$likedIds)?'true':'false'); ?>"><span aria-hidden="true">♡</span> <?php echo e($quote->likes_count); ?> <span class="sr-only">likes; toggle your like</span></button></form><form action="<?php echo e(route('quotes.save',$quote)); ?>" method="POST"><?php echo csrf_field(); ?><button type="submit" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['action','active'=>in_array($quote->id,$savedIds)]); ?>"><?php echo e(in_array($quote->id,$savedIds)?'Saved ✓':'Save +'); ?></button></form>
<a class="quiet-link report-link" href="<?php echo e(route('reports.create',$quote)); ?>">Report</a>
<?php else: ?><a class="action" href="<?php echo e(route('login')); ?>">♡ <?php echo e($quote->likes_count); ?> <span class="sr-only">likes; log in to interact</span></a><a class="action" href="<?php echo e(route('login')); ?>">Save +</a><?php endif; ?></div>
<?php if(auth()->guard()->check()): ?><div class="card-management"><?php if(in_array($quote->id,$savedIds)): ?><a class="quiet-link" href="<?php echo e(route('collections.index',['quote'=>$quote->id])); ?>">Organize in a collection ↗</a><?php endif; ?>
<?php if($quote->user_id===auth()->id()): ?><div class="owner-actions"><a href="<?php echo e(route('quotes.edit',$quote)); ?>">Edit</a><form action="<?php echo e(route('quotes.destroy',$quote)); ?>" method="POST" data-confirm="Delete this quote? This cannot be undone."><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="quiet-link danger-text" type="submit">Delete</button></form></div><?php endif; ?>
<?php if($collection): ?><form method="POST" action="<?php echo e(route('collections.remove',[$collection,$quote])); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="quiet-link" type="submit">Remove from this collection</button></form><?php endif; ?></div><?php endif; ?>
<?php if(in_array($quote->category,$resourceCategories)): ?><a class="related-link" href="<?php echo e(route('resources.index',['category'=>$quote->category])); ?>"><?php echo e($quote->category==='General'?'Explore health resources':'Learn more about '.strtolower($quote->category)); ?> <span aria-hidden="true">↗</span></a><?php endif; ?></article>
<?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\components\quote-card.blade.php ENDPATH**/ ?>