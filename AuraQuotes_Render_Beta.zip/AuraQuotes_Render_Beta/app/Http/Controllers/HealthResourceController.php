<?php
namespace App\Http\Controllers;
use App\Models\HealthResource;
use App\Models\Quote;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
class HealthResourceController extends Controller {
 public function index(Request $r) {
    $r->validate(['q'=>['nullable','string','max:200'],'category'=>['nullable',Rule::in(Quote::CATEGORIES)]]);
    $query=HealthResource::query();
    if($category=$r->query('category')){$query->where('category',$category);}
    if(($s=trim((string)$r->query('q','')))!==''){$query->where(fn($q)=>$q->whereLike('title',"%{$s}%")->orWhereLike('organization',"%{$s}%")->orWhereLike('description',"%{$s}%"));}
    $resources=$query->orderBy('organization')->orderBy('title')->paginate(9)->withQueryString();
    $categories=HealthResource::distinct()->orderBy('category')->pluck('category');
    return view('resources.index',compact('resources','categories'));
 }
}
