AuraQuotes assessment documentation pack

This pack contains SRS Word/PDF, the updated ERD PDF/Mermaid, an evidence-based review and a 60-second demo storyboard. It is NOT the complete source-code submission. All application code, original archives, source documents and live data were preserved.

Remaining work: demo video/link, password-boundary and language-restoration fixes/retests, measured acceptance tests, and a final approved source+documents ZIP.

Do not upload the original AQ (2).zip publicly without reviewing its local .env and account database. No values from those files are reproduced here.
