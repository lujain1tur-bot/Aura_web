# Aura Quotes ERD

```mermaid
erDiagram
    users |o--o{ quotes : publishes
    users ||--o{ quote_likes : likes
    quotes ||--o{ quote_likes : receives
    users ||--o{ quote_saves : saves
    quotes ||--o{ quote_saves : is_saved
    users ||--o{ user_interests : chooses
    users ||--o{ collections : owns
    collections ||--o{ collection_items : contains
    quotes ||--o{ collection_items : is_organized
    users |o--o{ quote_reports : submits
    quotes ||--o{ quote_reports : is_reported

    cache {
        varchar key PK "required"
        text value "required"
        integer expiration "required"
    }

    cache_locks {
        varchar key PK "required"
        varchar owner "required"
        integer expiration "required"
    }

    collection_items {
        integer id PK "required"
        integer collection_id FK "required"
        integer quote_id FK "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    collections {
        integer id PK "required"
        integer user_id FK "required"
        varchar name "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    failed_jobs {
        integer id PK "required"
        varchar uuid UK "required"
        varchar connection "required"
        varchar queue "required"
        text payload "required"
        text exception "required"
        datetime failed_at "required"
    }

    health_resources {
        integer id PK "required"
        varchar title "required"
        varchar organization "required"
        varchar category "required"
        text description "required"
        varchar url "required"
        varchar language "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    job_batches {
        varchar id PK "required"
        varchar name "required"
        integer total_jobs "required"
        integer pending_jobs "required"
        integer failed_jobs "required"
        text failed_job_ids "required"
        text options "nullable"
        integer cancelled_at "nullable"
        integer created_at "required"
        integer finished_at "nullable"
    }

    jobs {
        integer id PK "required"
        varchar queue "required"
        text payload "required"
        integer attempts "required"
        integer reserved_at "nullable"
        integer available_at "required"
        integer created_at "required"
    }

    migrations {
        integer id PK "required"
        varchar migration "required"
        integer batch "required"
    }

    password_reset_tokens {
        varchar email PK "required"
        varchar token "required"
        datetime created_at "nullable"
    }

    quote_likes {
        integer id PK "required"
        integer user_id FK "required"
        integer quote_id FK "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    quote_reports {
        integer id PK "required"
        integer user_id FK "nullable"
        integer quote_id FK "required"
        varchar reason "required"
        text details "nullable"
        varchar status "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    quote_saves {
        integer id PK "required"
        integer user_id FK "required"
        integer quote_id FK "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    quotes {
        integer id PK "required"
        integer user_id FK "nullable"
        text content "required"
        varchar category "required"
        varchar source_name "nullable"
        varchar source_type "required"
        tinyint is_verified "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
        varchar source_url "nullable"
    }

    sessions {
        varchar id PK "required"
        integer user_id "nullable"
        varchar ip_address "nullable"
        text user_agent "nullable"
        text payload "required"
        integer last_activity "required"
    }

    user_interests {
        integer id PK "required"
        integer user_id FK "required"
        varchar category "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    users {
        integer id PK "required"
        varchar name "required"
        varchar email UK "required"
        datetime email_verified_at "nullable"
        varchar password "required"
        varchar remember_token "nullable"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }
```
