<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class QuoteCollection extends Model {
    protected $table='collections'; protected $fillable=['name'];
    public function user() { return $this->belongsTo(User::class); }
    public function quotes() { return $this->belongsToMany(Quote::class,'collection_items','collection_id','quote_id')->withTimestamps(); }
}
