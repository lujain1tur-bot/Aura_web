@extends('layouts.app')
@section('title', 'Your session needs a refresh. | Aura Quotes')
@section('content')
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">419</span><h1>Your session needs a refresh.</h1><p>Please reload the page and try again.</p><a class="button button-primary" href="{{ route('quotes.index') }}">Return to the library</a></div></section>
@endsection
