<?php
namespace App\Http\Controllers;
use App\Models\Quote;
use App\Models\QuoteCollection;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
class CollectionController extends Controller {
 private function owner(Request $r,QuoteCollection $collection): void { abort_unless($collection->user_id===$r->user()->id,403,'This collection belongs to another account.'); }
 private function data(Request $r,?QuoteCollection $collection=null): array { return $r->validate(['name'=>['required','string','min:1','max:60',Rule::unique('collections','name')->where('user_id',$r->user()->id)->ignore($collection?->id)]]); }
 public function index(Request $r) {
    $r->validate(['quote'=>['nullable','integer']]);$quote=null;
    if($id=$r->query('quote')){$quote=$r->user()->savedQuotes()->findOrFail($id);}
    $collections=$r->user()->collections()->withCount('quotes')->orderBy('name')->get();
    return view('collections.index',compact('collections','quote'));
 }
 public function store(Request $r) { if($r->user()->collections()->count()>=20){return back()->withErrors(['name'=>'You can create up to 20 collections.']);}$r->user()->collections()->create($this->data($r));return back()->with('success','Collection created.'); }
 public function show(Request $r,QuoteCollection $collection) {
    $this->owner($r,$collection);$quotes=$collection->quotes()->with('user:id,name')->withCount('likes')->orderByDesc('quotes.created_at')->paginate(12)->withQueryString();
    $ids=$quotes->modelKeys();$likedIds=$r->user()->likedQuotes()->whereIn('quotes.id',$ids)->pluck('quotes.id')->all();$savedIds=$ids;$resourceCategories=[];
    return view('collections.show',compact('collection','quotes','likedIds','savedIds','resourceCategories'));
 }
 public function update(Request $r,QuoteCollection $collection) { $this->owner($r,$collection);$collection->update($this->data($r,$collection));return back()->with('success','Collection renamed.'); }
 public function destroy(Request $r,QuoteCollection $collection) { $this->owner($r,$collection);$collection->delete();return redirect()->route('collections.index')->with('success','Collection deleted. Your saved quotes are unchanged.'); }
 public function add(Request $r,QuoteCollection $collection) {
    $this->owner($r,$collection);$data=$r->validate(['quote_id'=>['required','integer']]);$quote=$r->user()->savedQuotes()->findOrFail($data['quote_id']);$collection->quotes()->syncWithoutDetaching([$quote->id]);return back()->with('success','Quote added to the collection.');
 }
 public function remove(Request $r,QuoteCollection $collection,Quote $quote) { $this->owner($r,$collection);$collection->quotes()->detach($quote->id);return back()->with('success','Quote removed from the collection. It remains saved.'); }
}
