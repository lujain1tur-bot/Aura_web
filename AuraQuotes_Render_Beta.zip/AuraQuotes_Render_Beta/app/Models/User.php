<?php

namespace App\Models;

use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

#[Fillable(['name', 'email', 'password'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    protected function casts(): array
    {
        return ['email_verified_at' => 'datetime', 'password' => 'hashed'];
    }

    public function interests() { return $this->hasMany(UserInterest::class); }
    public function collections() { return $this->hasMany(QuoteCollection::class); }
    public function reports() { return $this->hasMany(QuoteReport::class); }
    public function quotes(): HasMany { return $this->hasMany(Quote::class); }
    public function likedQuotes(): BelongsToMany { return $this->belongsToMany(Quote::class, 'quote_likes')->withTimestamps(); }
    public function savedQuotes(): BelongsToMany { return $this->belongsToMany(Quote::class, 'quote_saves')->withTimestamps(); }
}
