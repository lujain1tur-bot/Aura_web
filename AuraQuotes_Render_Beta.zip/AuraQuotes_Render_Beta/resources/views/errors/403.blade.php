@extends('layouts.app')
@section('title', 'This space is private. | Aura Quotes')
@section('content')
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">403</span><h1>This space is private.</h1><p>You do not have permission to change or view this item.</p><a class="button button-primary" href="{{ route('quotes.index') }}">Return to the library</a></div></section>
@endsection
