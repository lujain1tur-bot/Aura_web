<?php
declare(strict_types=1);

function deploymentKey(string $key, string $seed): string
{
    if ($key === '') {
        if (strlen($seed) < 32) {
            throw new RuntimeException('APP_KEY or an APP_KEY_SEED of at least 32 characters is required.');
        }
        $key = 'base64:'.base64_encode(hash('sha256', $seed, true));
    }
    $decoded = str_starts_with($key, 'base64:') ? base64_decode(substr($key, 7), true) : $key;
    if (!is_string($decoded) || strlen($decoded) !== 32) {
        throw new RuntimeException('APP_KEY must contain a valid 32-byte Laravel encryption key.');
    }
    return $key;
}

if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    try {
        echo deploymentKey(getenv('APP_KEY') ?: '', getenv('APP_KEY_SEED') ?: '');
    } catch (RuntimeException $exception) {
        fwrite(STDERR, $exception->getMessage().PHP_EOL);
        exit(1);
    }
}
