# AuraQuotes assessment review

Review date: 29 October 2026. This is an evidence-based readiness assessment, not an official competition score. The supplied guide defines requirements but no weighted scoring rubric. All original files and the deployed site were preserved.

## Overall decision

The implementation covers the core quote/account functions and exceeds the requirement for one additional database-backed feature. The submission is not yet complete: the demo video is missing, the supplied ERD is obsolete, the original source ZIP embeds older documentation, performance and first-use usability acceptance have not been proven, and two implementation edge cases need attention. New documentation copies address the schema/PDF gaps without modifying application behavior.

## Mandatory requirement matrix

| Guide requirement | Evidence | Assessment |
|---|---|---|
| Public quote text, publisher and date | QuoteController, index and quote-card views | Implemented; 12 results per page |
| Registration with name 2-50 and password >=8 | SignupController validation and User model | Implemented; password byte boundary remains an open finding |
| Login and logout | AuthController, guest/auth routes | Implemented with session renewal/invalidation |
| Publish text 3-155; edit/delete own quotes | QuoteController owner checks, validated forms | Implemented; protected server-side |
| At least one additional feature | Likes, saves, search, categories, interests, collections, resources and reports | Exceeds minimum; no need to add unrelated features |
| Blade inheritance and components | All 15 page/error views extend layouts.app; layout yields content; reusable components | Implemented |
| Password hashing | User hashed cast; synthetic bcrypt/cost-12 verification | Implemented; not reversible encryption; boundary finding below |
| Quotes page loads within 3 seconds | Existing HTTP checks and browser availability | Not established by a formal browser-load test; cold starts may exceed target |
| First quote within 1 minute without help | No observed timed first-time-user session | Pending user test |
| Helpful form hints | Shared field component; signup/publish/edit forms | Implemented; add byte-limit guidance with the password fix |
| Updated SRS in PDF | Latest SRS v1.6 assessment copy and PDF in this pack | Prepared; honest open findings retained |
| ERD matching final database in PDF | New English 17-table logical ERD plus Mermaid | Prepared; original 12-table ERD preserved |
| Full code and database setup files in named ZIP | AQ (2).zip exists; migrations, seeders and lockfile exist | Rebuild/rehearse final submission ZIP; embedded docs/README are stale |
| One-minute demo on accessible Google Drive link | User confirmed not prepared | Missing |
| Live URL | Public homepage reloaded successfully in Edge | Optional deliverable available; not an uptime guarantee |

## Findings in priority order

### P1 required submission readiness

1. Record the required one-minute screen demo and upload to Google Drive with viewer access for anyone with the link. Test access signed out. The deployed URL does not replace this required video.
2. Use the new English ERD rather than the attached older 3-page PDF. The older document has 12 tables and omits health_resources, user_interests, collections, collection_items and quote_reports. It also describes the older SQLite release rather than distinguishing the deployed PostgreSQL environment.
3. Put the matching SRS PDF, ERD PDF and source code into a new ZIP named in English, e.g. Lujain_AuraQuotes.zip. Keep the original archive unchanged. Include clear setup instructions, composer.json/lock, migrations, seeders and .env.example. Verify extraction and startup in a fresh short path before submission.
4. Measure NFR-01 in a real browser and NFR-04 with a first-time user. Record environment and results. Keep the original 3-second requirement; documenting a hosting limitation does not satisfy it. Do not claim a warm response proves cold-start compliance. A paid or alternative always-on environment would require a separate hosting decision; this review makes no spending commitment.

### P2 code and packaging corrections before a polished demonstration

5. Password byte boundary: an isolated unsaved-model test confirmed that synthetic strings differing only after byte 72 verify against the same bcrypt hash. The basic hashing requirement is met, but signup does not enforce the byte limit. Add explicit server-side byte-length validation and a clear form hint while retaining the minimum 8-character requirement and hashing cost. Test ASCII at 71/72/73 bytes, multibyte inputs, confirmation, ordinary valid passwords and existing-account login. Do not change stored account passwords or switch algorithms casually.
6. Language restoration: some Arabic-first/reload-to-English sequences retain Arabic text in the featured quote until an English reload. Capture original quote text before translation and add a regression check for EN > AR > reload > EN, including library/featured text. This needs a code correction; the documentation records it as open.
7. README and embedded docs: AQ (2).zip still describes English/dark only and claims the local database has no accounts, although metadata shows one account record. Update the README and place the approved final SRS/ERD copies into a new submission package. Do not submit stale PDF/DOCX versions alongside the new ones without clear version labels.
8. Local data/configuration in ZIP: the original archive includes .env and a local SQLite file with one account. Do not publish this archive unchanged. Review a clean distribution copy using .env.example, migrations and seeders, with no real account data or secrets. The user requested no deletion; no file, account or record was removed, and any exclusions/replacements in a code package require discussion first.

### P3 improvements after mandatory gaps

9. Add traceable test identifiers for ownership/CSRF, saved-quote isolation, collections, duplicate reports, mobile navigation and theme contrast. Existing source/integration evidence is useful, but is not a complete security audit or load test.
10. Make the submission easy to assess: one clear README, matching version/date in SRS and ERD, a changelog, reproducible setup and an explicit list of the additional features. Keep report submission distinct from moderation; do not add admin, music, mood detection or password-reset claims that are not implemented.

## SRS and ERD consistency rules

- Retain the reference Word document's nine sections and stable FR-01 to FR-17 identifiers; the new interface behavior is FR-18 to FR-20.
- Use bcrypt, cost 12 for the supplied configuration, independent random salts and Laravel hash verification. Do not describe passwords as decryptable, or suggest the application key decrypts password hashes. Test fixtures are synthetic; no account password was exposed.
- Separate local SQLite setup from the external PostgreSQL deployment. Model the same nine domain entities and eight infrastructure tables with accurate PK/FK/nullability/unique keys.
- Show user-to-quote ownership as optional on the quote side. Show likes/saves and collection membership as join tables. Show reports with nullable submitter. Show health-resource category matching as a textual association, not an invented FK.
- Browser language/theme settings do not require database columns. Presence of password_reset_tokens does not imply a reset UI. is_verified does not establish a clinical review process.
- Preserve unverified acceptance targets and known limitations; do not mark them passed to improve appearance.

## Demo storyboard for 60 seconds

| Time | Screen action |
|---|---|
| 0-8 s | Open the public library; show identity and quote/publisher/date |
| 8-18 s | Demonstrate account creation or login using a dedicated demo account; mask credential entry |
| 18-30 s | Publish a short quote, edit it, and demonstrate the own-quote delete confirmation |
| 30-43 s | Like/save a quote and organize it in a private collection |
| 43-53 s | Open official resources and show search/topic filtering |
| 53-60 s | Show language/theme controls and end on the live URL |

Use only a clearly identified disposable demo account/content. No live data was deleted or modified for this assessment. A recorded demo is evidence of the shown workflow, not a timed unassisted usability test.

## Evidence and limits

The input AQ (2).zip SHA-256 was d6320cad568882845f672cff5374977576f8c71a3f995b8c86119123cb7c2431, matching the latest deployment input recorded earlier. The latest local schema has 17 tables, eight applied migrations and zero foreign-key violations. Prior isolated integration verification passed 38 checks, and the local hashing inspection confirmed bcrypt with cost 12 and independent salts. This review additionally confirmed the >72-byte boundary behavior. All 15 application/error pages use Blade inheritance.

The public homepage was reloaded successfully in the user's Edge browser during this review. An independent Python HTTP request timed out and the web-fetch service could not fetch the page. This mixed connectivity evidence does not establish downtime or prove the 3-second target. No production data, deployment settings, account passwords or application code were changed. No newly recorded video was available. No official score or guaranteed competition result is claimed.

Primary technical references: [Render free-instance limitations](https://render.com/docs/free#spinning-down-on-idle) and [PHP bcrypt password hashing](https://www.php.net/manual/en/function.password-hash.php).
