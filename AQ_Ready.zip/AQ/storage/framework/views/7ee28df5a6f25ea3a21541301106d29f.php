
<?php $__env->startSection('title', 'Take a short pause. | Aura Quotes'); ?>
<?php $__env->startSection('content'); ?>
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">429</span><h1>Take a short pause.</h1><p>Too many requests. Please wait a minute and try again.</p><a class="button button-primary" href="<?php echo e(route('quotes.index')); ?>">Return to the library</a></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\errors\429.blade.php ENDPATH**/ ?>