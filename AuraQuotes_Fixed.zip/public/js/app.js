const interfaceTranslations = {
  'At least 8 characters. Maximum 72 bytes; some characters use more than one byte.': '8 أحرف على الأقل، وبحد أقصى 72 بايت؛ بعض الأحرف تستهلك أكثر من بايت.',
  'Password must be 72 bytes or fewer. Please use a shorter password.': 'يجب ألا يتجاوز حجم كلمة المرور 72 بايت. يرجى استخدام كلمة مرور أقصر.',
  'A mindful corner of the internet': 'مساحة هادئة على الإنترنت',
  'Small words.': 'كلمات صغيرة.',
  'A healthier': 'نحو صحة أفضل',
  'perspective.': 'ومنظور أجمل.',
  'Explore thoughtful words on health and everyday life. Keep what resonates, share what matters, and find trusted places to learn more.': 'اكتشف كلمات ملهمة عن الصحة والحياة اليومية. احتفظ بما يلامسك، وشارك ما يهمك، وتعرّف على مصادر موثوقة للمزيد.',
  'Explore the library': 'استكشف المكتبة',
  'Official health resources': 'مصادر صحية رسمية',
  'A moment to pause.': 'لحظة للتأمل.',
  'Something worth keeping.': 'شيء يستحق الاحتفاظ به.',
  'THE AURA PERSPECTIVE': 'رؤية أورا',
  'One small, realistic step today is better than an endlessly postponed perfect plan.': 'خطوة صغيرة وواقعية اليوم أفضل من خطة مثالية نؤجلها إلى ما لا نهاية.',
  'Mental wellbeing': 'الصحة النفسية',
  'Take what helps. Return when you need.': 'خذ ما يفيدك، وعد متى احتجت.',
  'YOUR WORDS MATTER': 'كلماتك مهمة',
  'Share a little perspective': 'شاركنا فكرة ملهمة',
  'Your quote': 'اقتباسك',
  '3–155 characters. Text only.': 'من 3 إلى 155 حرفًا. نص فقط.',
  'A thought worth sharing…': 'فكرة تستحق المشاركة…',
  'Category': 'التصنيف',
  'Choose a topic for your quote.': 'اختر موضوعًا لاقتباسك.',
  'Select a category': 'اختر تصنيفًا',
  'Author or source': 'الكاتب أو المصدر',
  'Optional. Up to 120 characters.': 'اختياري. حتى 120 حرفًا.',
  'Author name': 'اسم الكاتب',
  'Publish quote ↗': 'انشر الاقتباس ↗',
  'THE LIBRARY': 'المكتبة',
  'Find a thought to keep.': 'اعثر على فكرة تحتفظ بها.',
  'A collection of words for everyday wellbeing.': 'مجموعة من الكلمات الملهمة لحياة يومية أفضل.',
  'My saved quotes ↗': 'اقتباساتي المحفوظة ↗',
  'Search quotes': 'ابحث في الاقتباسات',
  'Search words, authors or topics…': 'ابحث عن كلمات أو كتّاب أو موضوعات…',
  'Search': 'بحث',
  'Category filters': 'تصفية حسب التصنيف',
  'All topics': 'كل الموضوعات',
  'quote': 'اقتباس',
  'quotes': 'اقتباسات',
  ' · My saved quotes': ' · اقتباساتي المحفوظة',
  'For you': 'مقترح لك',
  'Newest': 'الأحدث',
  'Choose your interests ↗': 'اختر اهتماماتك ↗',
  'Clear filters': 'مسح عوامل التصفية',
  'No quotes here yet.': 'لا توجد اقتباسات هنا بعد.',
  'Try another search or topic, or save a quote to start your collection.': 'جرّب البحث عن موضوع آخر، أو احفظ اقتباسًا لبدء مجموعتك.',
  'Back to the library': 'العودة إلى المكتبة',
  'KEEP EXPLORING': 'واصل الاستكشاف',
  'A thought starts here.': 'تبدأ الفكرة هنا.',
  'The learning goes further.': 'ويستمر التعلّم بعدها.',
  'Small words. A little more perspective.': 'كلمات صغيرة، ومنظور أوسع.',
  'Educational content, not a substitute for professional care.': 'محتوى تثقيفي لا يغني عن الرعاية المتخصصة.',
  'Explore official resources from the Saudi Ministry of Health and Weqaya.': 'استكشف المصادر الرسمية من وزارة الصحة السعودية ووقاية.',
  'Visit health resources ↗': 'تصفّح المصادر الصحية ↗',
  'TRUSTED PLACES TO LEARN': 'مصادر موثوقة للمعرفة',
  'Health resources.': 'مصادر صحية.',
  'Continue your reading with official health organizations. Each link takes you directly to the original website.': 'تابع القراءة من خلال الجهات الصحية الرسمية. ينقلك كل رابط مباشرة إلى الموقع الأصلي.',
  'Search resources': 'ابحث في المصادر',
  'Search resources or organizations…': 'ابحث عن مصادر أو جهات…',
  'Topic': 'الموضوع',
  'Find resources': 'ابحث عن مصادر',
  'Clear filters': 'مسح عوامل التصفية',
  'Visit official source ↗': 'زيارة المصدر الرسمي ↗',
  'No matching resources.': 'لا توجد مصادر مطابقة.',
  'Try another topic or clear the search.': 'جرّب موضوعًا آخر أو امسح البحث.',
  'Ministry of Health awareness platform': 'منصة التوعية بوزارة الصحة',
  'Weqaya public health portal': 'بوابة وقاية للصحة العامة',
  'Asthma health resources': 'مصادر صحية عن الربو',
  'Nutrition health resources': 'مصادر صحية عن التغذية',
  'Physical activity health resources': 'مصادر صحية عن النشاط البدني',
  'Sleep health resources': 'مصادر صحية عن النوم',
  'Mental wellbeing health resources': 'مصادر صحية عن الصحة النفسية',
  'Prevention health resources': 'مصادر صحية عن الوقاية',
  'Diabetes health resources': 'مصادر صحية عن السكري',
  'Blood pressure health resources': 'مصادر صحية عن ضغط الدم',
  'Smoking health resources': 'مصادر صحية عن التدخين',
  'Oral health resources': 'مصادر صحية عن صحة الفم',
  'Family health resources': 'مصادر صحية عن صحة الأسرة',
  'Saudi Ministry of Health': 'وزارة الصحة السعودية',
  'Public Health Authority — Weqaya': 'هيئة الصحة العامة — وقاية',
  'World Health Organization': 'منظمة الصحة العالمية',
  'English': 'الإنجليزية',
  'Arabic': 'العربية',
  'Explore the Ministry of Health public awareness library and its topic sections.': 'استكشف مكتبة التوعية العامة بوزارة الصحة وأقسام موضوعاتها.',
  'Visit Saudi Arabia’s Public Health Authority for public health information and official resources.': 'تعرّف على معلومات الصحة العامة والمصادر الرسمية لدى هيئة الصحة العامة في المملكة العربية السعودية.',
  'Explore the official chronic disease section for further information related to asthma.': 'استكشف قسم الأمراض المزمنة الرسمي لمعرفة المزيد عن الربو.',
  'Explore the official healthy lifestyle section for further information related to nutrition.': 'استكشف قسم نمط الحياة الصحي الرسمي لمعرفة المزيد عن التغذية.',
  'Explore the official healthy lifestyle section for further information related to physical activity.': 'استكشف قسم نمط الحياة الصحي الرسمي لمعرفة المزيد عن النشاط البدني.',
  'Explore the official healthy lifestyle section for further information related to sleep.': 'استكشف قسم نمط الحياة الصحي الرسمي لمعرفة المزيد عن النوم.',
  'Explore the official healthy lifestyle section for further information related to mental wellbeing.': 'استكشف قسم نمط الحياة الصحي الرسمي لمعرفة المزيد عن الصحة النفسية.',
  'Explore the official health awareness section for further information related to prevention.': 'استكشف قسم التوعية الصحية الرسمي لمعرفة المزيد عن الوقاية.',
  'Explore the official chronic disease section for further information related to diabetes.': 'استكشف قسم الأمراض المزمنة الرسمي لمعرفة المزيد عن السكري.',
  'Explore the official chronic disease section for further information related to blood pressure.': 'استكشف قسم الأمراض المزمنة الرسمي لمعرفة المزيد عن ضغط الدم.',
  'Explore the official healthy lifestyle section for further information related to smoking.': 'استكشف قسم نمط الحياة الصحي الرسمي لمعرفة المزيد عن التدخين.',
  'Explore the official oral health section for further information related to oral health.': 'استكشف قسم صحة الفم الرسمي لمعرفة المزيد عن صحة الفم.',
  'Explore the official health awareness section for further information related to family health.': 'استكشف قسم التوعية الصحية الرسمي لمعرفة المزيد عن صحة الأسرة.',
  'YOUR WORDS ARE WAITING': 'اقتباساتك بانتظارك',
  'A familiar': 'مكانك المألوف',
  'place to pause.': 'للتوقف والتأمل.',
  'Return to your saved quotes and the thoughts that matter to you.': 'عُد إلى اقتباساتك المحفوظة والأفكار التي تهمك.',
  'Welcome back': 'مرحبًا بعودتك',
  'Email address': 'البريد الإلكتروني',
  'The email used for your account.': 'البريد الإلكتروني المستخدم لحسابك.',
  'Password': 'كلمة المرور',
  'Enter your account password.': 'أدخل كلمة مرور حسابك.',
  'Remember me on this device': 'تذكّرني على هذا الجهاز',
  'Log in ↗': 'تسجيل الدخول ↗',
  'New here?': 'جديد هنا؟',
  'Create an account': 'إنشاء حساب',
  'A LITTLE SPACE FOR YOURSELF': 'مساحة صغيرة لك',
  'Make yourself': 'اجعل المكان',
  'at home.': 'مكانك.',
  'Save meaningful words, discover your interests, and share a perspective of your own.': 'احفظ الكلمات التي تعني لك، واكتشف اهتماماتك، وشاركنا رؤيتك.',
  'Create your account': 'أنشئ حسابك',
  'Your name': 'اسمك',
  '2–50 characters.': 'من حرفين إلى 50 حرفًا.',
  'Use a valid email that is not already registered.': 'استخدم بريدًا إلكترونيًا صحيحًا غير مسجل من قبل.',
  'At least 8 characters.': '8 أحرف على الأقل.',
  'Confirm password': 'تأكيد كلمة المرور',
  'Enter the same password again.': 'أعد إدخال كلمة المرور نفسها.',
  'Create account ↗': 'إنشاء الحساب ↗',
  'Already a member?': 'لديك حساب بالفعل؟',
  'WORDS WORTH RETURNING TO': 'كلمات تستحق العودة إليها',
  'Your collections.': 'مجموعاتك.',
  'Arrange saved quotes into private collections. Your collection names and memberships are visible only to you.': 'رتّب الاقتباسات المحفوظة في مجموعات خاصة. لا يطّلع على أسماء مجموعاتك ومحتوياتها سواك.',
  'Organize this saved quote': 'نظّم هذا الاقتباس المحفوظ',
  'Choose a collection': 'اختر مجموعة',
  'A quote may be in more than one collection.': 'يمكن إضافة الاقتباس إلى أكثر من مجموعة.',
  'Add to collection': 'أضف إلى المجموعة',
  'Create a collection below, then choose it here.': 'أنشئ مجموعة أدناه، ثم اخترها هنا.',
  'Create a collection': 'إنشاء مجموعة',
  'Collection name': 'اسم المجموعة',
  '1–60 characters. Up to 20 collections per account.': 'من حرف إلى 60 حرفًا. حتى 20 مجموعة لكل حساب.',
  'For calmer days': 'لأيام أكثر هدوءًا',
  'Create collection +': 'إنشاء مجموعة +',
  'saved': 'محفوظ',
  'Your first collection starts here.': 'تبدأ مجموعتك الأولى من هنا.',
  'Create a collection, save a quote, and select “Organize in a collection”.': 'أنشئ مجموعة، واحفظ اقتباسًا، ثم اختر «نظّم في مجموعة».',
  '← All collections': '← كل المجموعات',
  'Private collection': 'مجموعة خاصة',
  'Manage this collection': 'إدارة هذه المجموعة',
  'Rename': 'إعادة التسمية',
  'Delete collection': 'حذف المجموعة',
  'Delete this collection? Its quotes will remain saved.': 'هل تريد حذف هذه المجموعة؟ ستبقى اقتباساتها محفوظة.',
  'A little room for inspiration.': 'مساحة صغيرة للإلهام.',
  'Open your saved quotes and organize them into this collection.': 'افتح اقتباساتك المحفوظة ونظّمها في هذه المجموعة.',
  'Open saved quotes': 'افتح الاقتباسات المحفوظة',
  'MAKE SPACE FOR WHAT MATTERS': 'امنح ما يهمك مساحة',
  'Your interests.': 'اهتماماتك.',
  'Choose the topics you would like to see first. You can always switch to the newest quotes or clear your choices.': 'اختر الموضوعات التي تود رؤيتها أولًا. يمكنك دائمًا عرض الأحدث أو إزالة اختياراتك.',
  'Select your topics': 'اختر موضوعاتك',
  'Save interests ↗': 'احفظ الاهتمامات ↗',
  'Back to library': 'العودة إلى المكتبة',
  'Uncheck every topic and save to return to an unpersonalized feed.': 'أزل تحديد كل الموضوعات واحفظ للعودة إلى عرض عام.',
  'YOUR PRIVATE SUBMISSIONS': 'بلاغاتك الخاصة',
  'Your reports.': 'بلاغاتك.',
  'A record of the concerns you submitted. Reports remain open; submission does not remove content automatically.': 'سجل بالملاحظات التي أرسلتها. تظل البلاغات مفتوحة، ولا يؤدي إرسالها إلى إزالة المحتوى تلقائيًا.',
  'Submitted ': 'تاريخ الإرسال ',
  'No reports submitted.': 'لم ترسل أي بلاغات.',
  'You can report a quote from its card in the library.': 'يمكنك الإبلاغ عن اقتباس من بطاقته في المكتبة.',
  'HELP KEEP THE COMMUNITY THOUGHTFUL': 'ساعدنا في الحفاظ على مجتمع واعٍ',
  'Report a quote.': 'الإبلاغ عن اقتباس.',
  'Tell us what concerns you. Your report is private and does not automatically remove the quote.': 'أخبرنا بسبب قلقك. بلاغك خاص ولا يزيل الاقتباس تلقائيًا.',
  'Reason': 'السبب',
  'Choose the option that best describes the issue.': 'اختر الخيار الذي يصف المشكلة بدقة.',
  'Select a reason': 'اختر سببًا',
  'Additional details': 'تفاصيل إضافية',
  'Optional. Up to 1,000 characters. Do not include sensitive personal information.': 'اختياري. حتى 1,000 حرف. لا تُدرج معلومات شخصية حساسة.',
  'Submit report': 'إرسال البلاغ',
  'Cancel': 'إلغاء',
  'A THOUGHT CAN EVOLVE': 'قد تتطور الفكرة',
  'Edit your quote.': 'تعديل اقتباسك.',
  'Choose a supported topic.': 'اختر موضوعًا من القائمة.',
  'Save changes': 'حفظ التغييرات',
  'Community contribution': 'مساهمة مجتمعية',
  'Source ↗': 'المصدر ↗',
  'By ': 'بواسطة ',
  'likes; toggle your like': 'إعجاب؛ اضغط لتغيير إعجابك',
  'Saved ✓': 'تم الحفظ ✓',
  'Save +': 'حفظ +',
  'Report': 'إبلاغ',
  'likes; log in to interact': 'إعجاب؛ سجّل الدخول للتفاعل',
  'Organize in a collection ↗': 'نظّم في مجموعة ↗',
  'Edit': 'تعديل',
  'Delete': 'حذف',
  'Delete this quote? This cannot be undone.': 'هل تريد حذف هذا الاقتباس؟ لا يمكن التراجع عن ذلك.',
  'Remove from this collection': 'إزالة من هذه المجموعة',
  'Explore health resources': 'استكشف المصادر الصحية',
  'Learn more about ': 'اعرف المزيد عن ',
  'Small words. A little more perspective.': 'كلمات صغيرة، ومنظور أوسع.',
  'Explore official health resources ↗': 'استكشف المصادر الصحية الرسمية ↗',
  'Educational content, not a substitute for professional care.': 'محتوى تثقيفي لا يغني عن الرعاية المتخصصة.',
  'Please check your details.': 'يرجى التحقق من البيانات المدخلة.',
  'Skip to content': 'انتقل إلى المحتوى',
  'Main navigation': 'التنقل الرئيسي',
  'Language': 'اللغة',
  'Toggle dark mode': 'تبديل الوضع الداكن',
  'Switch to dark mode': 'التبديل إلى الوضع الداكن',
  'Switch to light mode': 'التبديل إلى الوضع الفاتح',
  'Log out': 'تسجيل الخروج',
  'Log in': 'تسجيل الدخول',
  'Join Aura': 'انضم إلى أورا',
  'Library': 'المكتبة',
  'Words for your wellbeing': 'كلمات من أجل عافيتك',
  'Aura Quotes': 'AuraQuotes',
  'Open': 'مفتوح',
  'Health resources': 'المصادر الصحية',
  'Interests': 'الاهتمامات',
  'Collections': 'المجموعات',
  'My reports': 'بلاغاتي',
  'A little off the path.': 'يبدو أنك ابتعدت قليلًا.',
  'This page or item could not be found.': 'تعذّر العثور على هذه الصفحة أو العنصر.',
  'Return to the library': 'العودة إلى المكتبة',
  'This space is private.': 'هذه المساحة خاصة.',
  'You do not have permission to change or view this item.': 'ليست لديك صلاحية عرض هذا العنصر أو تغييره.',
  'Your session needs a refresh.': 'تحتاج جلستك إلى التحديث.',
  'Please reload the page and try again.': 'يرجى تحديث الصفحة ثم المحاولة مجددًا.',
  'Take a short pause.': 'خذ استراحة قصيرة.',
  'Too many requests. Please wait a minute and try again.': 'عدد الطلبات كبير. انتظر دقيقة ثم حاول مجددًا.',
  'Something needs a moment.': 'حدثت مشكلة مؤقتة.',
  'We could not complete the request. Please try again shortly.': 'تعذّر إكمال الطلب. يرجى المحاولة بعد قليل.',
  'Aura Quotes · A little more perspective': 'أورا · منظور أوسع قليلًا',
  'Submitted': 'تاريخ الإرسال',
  'By': 'بواسطة',
  'A little more perspective': 'منظور أوسع قليلًا',
  'Health resources | Aura Quotes': 'المصادر الصحية | أورا',
  'Welcome back | Aura Quotes': 'مرحبًا بعودتك | أورا',
  'Join Aura | Aura Quotes': 'انضم إلى أورا',
  'Your collections | Aura Quotes': 'مجموعاتك | أورا',
  'Collection | Aura Quotes': 'مجموعة | أورا',
  'Your interests | Aura Quotes': 'اهتماماتك | أورا',
  'Your reports | Aura Quotes': 'بلاغاتك | أورا',
  'Report a quote | Aura Quotes': 'الإبلاغ عن اقتباس | أورا',
  'Edit your quote | Aura Quotes': 'تعديل اقتباسك | أورا',
  'A little off the path. | Aura Quotes': 'يبدو أنك ابتعدت قليلًا | أورا',
  'This space is private. | Aura Quotes': 'هذه المساحة خاصة | أورا',
  'Your session needs a refresh. | Aura Quotes': 'تحتاج جلستك إلى التحديث | أورا',
  'Take a short pause. | Aura Quotes': 'خذ استراحة قصيرة | أورا',
  'Something needs a moment. | Aura Quotes': 'حدثت مشكلة مؤقتة | أورا',
  'Page ': 'الصفحة ',
  ' of ': ' من ',
  '← Previous': 'السابق →',
  'Next →': '← التالي',
  'quote · My saved quotes': 'اقتباس · اقتباساتي المحفوظة',
  'quotes · My saved quotes': 'اقتباسات · اقتباساتي المحفوظة',
  'quote saved': 'اقتباس محفوظ',
  'quotes saved': 'اقتباسات محفوظة',
  'General': 'عام',
  'Life': 'الحياة',
  'Success': 'النجاح',
  'Wisdom': 'الحكمة',
  'Happiness': 'السعادة',
  'Motivation': 'التحفيز',
  'Asthma': 'الربو',
  'Nutrition': 'التغذية',
  'Physical activity': 'النشاط البدني',
  'Sleep': 'النوم',
  'Prevention': 'الوقاية',
  'Diabetes': 'السكري',
  'Blood pressure': 'ضغط الدم',
  'Smoking': 'التدخين',
  'Oral health': 'صحة الفم',
  'Family health': 'صحة الأسرة',
  'Misinformation': 'معلومات مضللة',
  'Inappropriate content': 'محتوى غير لائق',
  'Harassment or hate': 'تحرش أو خطاب كراهية',
  'Copyright concern': 'مشكلة متعلقة بحقوق النشر',
  'Other': 'أخرى'
};

const categoryTranslations = {
  'Mental wellbeing': 'الصحة النفسية',
  'Physical activity': 'النشاط البدني',
  'Blood pressure': 'ضغط الدم',
  'Oral health': 'صحة الفم',
  'Family health': 'صحة الأسرة'
};

const originalText = new WeakMap();
const originalQuoteText = new WeakMap();
const originalDates = new WeakMap();
let quoteTranslations = {};
const languageKey = 'aura_language';
const themeKey = 'aura_theme';

function translateString(value, language) {
  const trimmed = value.trim();
  if (!trimmed) return value;
  let translated = interfaceTranslations[trimmed] || interfaceTranslations[`${trimmed} `] || categoryTranslations[trimmed];

  if (!translated) {
    const countMatch = trimmed.match(/^(\d+) (saved )?(quotes?)( · My saved quotes)?( · Private collection)?$/);
    const pageMatch = trimmed.match(/^Page (\d+) of (\d+)$/);
    const relatedMatch = trimmed.match(/^Learn more about (.+)$/);
    const authorMatch = trimmed.match(/^By (.+)$/);
    const footerMatch = trimmed.match(/^© (\d{4}) AuraQuotes · Educational content, not a substitute for professional care\.$/);
    if (countMatch) {
      const count = countMatch[1];
        const quoteLabel = count === '1' ? 'اقتباس' : 'اقتباسات';
        translated = countMatch[2]
          ? `${count} ${quoteLabel} ${count === '1' ? 'محفوظ' : 'محفوظة'}`
          : `${count} ${quoteLabel}`;
        if (countMatch[4]) translated += ' · اقتباساتي المحفوظة';
        if (countMatch[5]) translated += ' · مجموعة خاصة';
    } else if (pageMatch) {
      translated = `الصفحة ${pageMatch[1]} من ${pageMatch[2]}`;
    } else if (relatedMatch) {
      const category = relatedMatch[1];
      translated = `اعرف المزيد عن ${categoryTranslations[category] || interfaceTranslations[category] || category}`;
    } else if (authorMatch) {
      translated = `بواسطة ${authorMatch[1] === 'Aura Quotes' ? 'AuraQuotes' : authorMatch[1]}`;
    } else if (footerMatch) {
      translated = `© ${footerMatch[1]} AuraQuotes · محتوى تثقيفي لا يغني عن الرعاية المتخصصة.`;
    } else {
      return value;
    }
  }

  const start = value.indexOf(trimmed);
  return `${value.slice(0, start)}${language === 'ar' ? translated : trimmed}${value.slice(start + trimmed.length)}`;
}

let originalTitle;
function applyLanguage(language) {
  const selectedLanguage = language === 'ar' ? 'ar' : 'en';
  document.documentElement.lang = selectedLanguage;
  document.documentElement.dir = selectedLanguage === 'ar' ? 'rtl' : 'ltr';
  document.body.dir = selectedLanguage === 'ar' ? 'rtl' : 'ltr';
  if (originalTitle === undefined) originalTitle = document.title;
  document.title = translateString(originalTitle, selectedLanguage);

  // Capture source text before the general interface translator touches quote nodes.
  const quotes = document.querySelectorAll('.quote-card blockquote, .featured-card blockquote, .organize-panel blockquote, .report-card blockquote, .form-panel blockquote');
  quotes.forEach((quote) => {
    if (!originalQuoteText.has(quote)) originalQuoteText.set(quote, quote.textContent.trim());
  });

  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    if (!originalText.has(node)) originalText.set(node, node.nodeValue);
    node.nodeValue = translateString(originalText.get(node), selectedLanguage);
  }

  quotes.forEach((quote) => {
    const english = originalQuoteText.get(quote);
    quote.textContent = selectedLanguage === 'ar' ? (quoteTranslations[english] || english) : english;
  });

  document.querySelectorAll('time[datetime]').forEach((time) => {
    if (!originalDates.has(time)) originalDates.set(time, new Date(time.dateTime));
    const date = originalDates.get(time);
    time.textContent = new Intl.DateTimeFormat(selectedLanguage === 'ar' ? 'ar' : 'en', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  });

  document.querySelectorAll('[placeholder], [aria-label], [title]').forEach((element) => {
    ['placeholder', 'aria-label', 'title'].forEach((attribute) => {
      if (!element.hasAttribute(attribute)) return;
      const key = `data-original-${attribute}`;
      if (!element.hasAttribute(key)) element.setAttribute(key, element.getAttribute(attribute));
      element.setAttribute(attribute, translateString(element.getAttribute(key), selectedLanguage).trim());
    });
  });

  const languageSelect = document.getElementById('lang-switch');
  if (languageSelect) languageSelect.value = selectedLanguage;
  localStorage.setItem(languageKey, selectedLanguage);
}

function applyTheme(theme) {
  const selectedTheme = theme === 'light' ? 'light' : 'dark';
  const lightMode = selectedTheme === 'light';
  document.body.classList.toggle('theme-light', lightMode);
  document.documentElement.style.colorScheme = selectedTheme;

  const toggle = document.getElementById('theme-toggle');
  if (toggle) {
    toggle.textContent = lightMode ? '☀' : '☾';
    const label = lightMode ? 'Switch to dark mode' : 'Switch to light mode';
    toggle.setAttribute('aria-label', translateString(label, document.documentElement.lang));
  }
  localStorage.setItem(themeKey, selectedTheme);
}

document.addEventListener('DOMContentLoaded', () => {
  fetch('/quote-translations.json')
    .then((response) => {
      if (!response.ok) throw new Error(`Could not load quote translations: HTTP ${response.status}`);
      return response.json();
    })
    .then((translations) => {
      quoteTranslations = translations;
      applyLanguage(localStorage.getItem(languageKey) || 'en');
      applyTheme(localStorage.getItem(themeKey) || 'dark');
    })
    .catch((error) => {
      console.error(error);
      applyLanguage(localStorage.getItem(languageKey) || 'en');
      applyTheme(localStorage.getItem(themeKey) || 'dark');
    });

  document.getElementById('lang-switch')?.addEventListener('change', (event) => {
    applyLanguage(event.target.value);
    applyTheme(localStorage.getItem(themeKey) || 'dark');
  });

  document.getElementById('theme-toggle')?.addEventListener('click', () => {
    applyTheme(document.body.classList.contains('theme-light') ? 'dark' : 'light');
  });
});

document.addEventListener('submit', (event) => {
  const message = event.target.dataset.confirm;
  if (message && !window.confirm(translateString(message, document.documentElement.lang).trim())) {
    event.preventDefault();
  }
});

document.addEventListener('change', (event) => {
  const target = event.target.dataset.collectionTarget;
  if (target) {
    const form = document.getElementById(target);
    if (form) form.action = event.target.value;
  }
});
