
<?php $__env->startSection('title', 'This space is private. | Aura Quotes'); ?>
<?php $__env->startSection('content'); ?>
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">403</span><h1>This space is private.</h1><p>You do not have permission to change or view this item.</p><a class="button button-primary" href="<?php echo e(route('quotes.index')); ?>">Return to the library</a></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\errors\403.blade.php ENDPATH**/ ?>