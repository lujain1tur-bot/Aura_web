
<?php $__env->startSection('title', 'Your collections | Aura Quotes'); ?>
<?php $__env->startSection('content'); ?>
<section class="wrap content-page"><div class="page-heading"><span class="eyebrow">WORDS WORTH RETURNING TO</span><h1>Your collections.</h1><p>Arrange saved quotes into private collections. Your collection names and memberships are visible only to you.</p></div>
<?php if($quote): ?><div class="panel organize-panel"><h2>Organize this saved quote</h2><blockquote><?php echo e($quote->content); ?></blockquote><?php if($collections->isNotEmpty()): ?><form method="POST" action="<?php echo e(route('collections.add',$collections->first())); ?>" id="organize-form"><?php echo csrf_field(); ?><input type="hidden" name="quote_id" value="<?php echo e($quote->id); ?>"><?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['id' => 'collection-choice','label' => 'Choose a collection','hint' => 'A quote may be in more than one collection.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'collection-choice','label' => 'Choose a collection','hint' => 'A quote may be in more than one collection.']); ?><select id="collection-choice" required data-collection-target="organize-form"><?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e(route('collections.add',$item)); ?>"><?php echo e($item->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?><button class="button button-primary">Add to collection</button></form><?php else: ?><p>Create a collection below, then choose it here.</p><?php endif; ?></div><?php endif; ?>
<div class="two-column"><form class="panel form-panel" action="<?php echo e(route('collections.store',request()->only('quote'))); ?>" method="POST"><?php echo csrf_field(); ?><h2>Create a collection</h2><?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['id' => 'name','label' => 'Collection name','hint' => '1–60 characters. Up to 20 collections per account.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'name','label' => 'Collection name','hint' => '1–60 characters. Up to 20 collections per account.']); ?><input id="name" name="name" required maxlength="60" value="<?php echo e(old('name')); ?>" placeholder="For calmer days"> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?><button class="button button-primary">Create collection +</button></form><div class="collection-list"><?php $__empty_1 = true; $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><a class="panel collection-card" href="<?php echo e(route('collections.show',$item)); ?>"><span class="collection-icon" aria-hidden="true">▤</span><span><strong><?php echo e($item->name); ?></strong><small><?php echo e($item->quotes_count); ?> saved <?php echo e(Str::plural('quote',$item->quotes_count)); ?></small></span><span aria-hidden="true">↗</span></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="panel empty-state"><h2>Your first collection starts here.</h2><p>Create a collection, save a quote, and select “Organize in a collection”.</p></div><?php endif; ?></div></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\collections\index.blade.php ENDPATH**/ ?>