<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
return new class extends Migration {
 public function up(): void {
    Schema::create('health_resources',function(Blueprint $t){
        $t->id();$t->string('title',160);$t->string('organization',120);$t->string('category',60)->index();
        $t->text('description');$t->string('url',2048);$t->string('language',20)->default('English');$t->timestamps();
        $t->unique(['category','title']);
    });
    Schema::create('user_interests',function(Blueprint $t){$t->id();$t->foreignId('user_id')->constrained()->cascadeOnDelete();$t->string('category',60);$t->timestamps();$t->unique(['user_id','category']);});
    Schema::create('collections',function(Blueprint $t){$t->id();$t->foreignId('user_id')->constrained()->cascadeOnDelete();$t->string('name',60);$t->timestamps();$t->unique(['user_id','name']);});
    Schema::create('collection_items',function(Blueprint $t){$t->id();$t->foreignId('collection_id')->constrained('collections')->cascadeOnDelete();$t->foreignId('quote_id')->constrained()->cascadeOnDelete();$t->timestamps();$t->unique(['collection_id','quote_id']);});
    Schema::create('quote_reports',function(Blueprint $t){$t->id();$t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();$t->foreignId('quote_id')->constrained()->cascadeOnDelete();$t->string('reason',100);$t->text('details')->nullable();$t->string('status',20)->default('open');$t->timestamps();$t->unique(['user_id','quote_id']);});
    Schema::table('quotes',function(Blueprint $t){$t->index(['category','created_at','id'],'quotes_category_date_index');});
    $map=['عام'=>'General','الحياة'=>'Life','النجاح'=>'Success','الحكمة'=>'Wisdom','السعادة'=>'Happiness','التحفيز'=>'Motivation','الربو'=>'Asthma','التغذية'=>'Nutrition','النشاط البدني'=>'Physical activity','النوم'=>'Sleep','الصحة النفسية'=>'Mental wellbeing','الوقاية'=>'Prevention','السكري'=>'Diabetes','ضغط الدم'=>'Blood pressure','التدخين'=>'Smoking','صحة الفم'=>'Oral health','صحة الأسرة'=>'Family health'];
    foreach($map as $old=>$new){DB::table('quotes')->where('category',$old)->update(['category'=>$new]);}
 }
 public function down(): void {
    Schema::dropIfExists('quote_reports');Schema::dropIfExists('collection_items');Schema::dropIfExists('collections');Schema::dropIfExists('user_interests');Schema::dropIfExists('health_resources');
    Schema::table('quotes',fn(Blueprint $t)=>$t->dropIndex('quotes_category_date_index'));
 }
};
