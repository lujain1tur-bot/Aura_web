<?php
// Exercise the real updated controller, hashing and validation with an isolated DB.
putenv('APP_ENV=testing');putenv('DB_CONNECTION=sqlite');putenv('DB_DATABASE=:memory:');
putenv('CACHE_STORE=array');putenv('SESSION_DRIVER=array');putenv('BCRYPT_ROUNDS=12');
putenv('APP_KEY=base64:'.base64_encode(str_repeat('T',32)));
require __DIR__.'/../vendor/autoload.php';
$app=require __DIR__.'/../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
set_exception_handler(function (Throwable $e): void {fwrite(STDERR,'FAIL: '.$e->getMessage().PHP_EOL);exit(1);});
$app['config']->set('database.default','sqlite');$app['config']->set('database.connections.sqlite.database',':memory:');
$app['config']->set('cache.default','array');$app['config']->set('session.driver','array');
Illuminate\Support\Facades\DB::purge('sqlite');
Illuminate\Support\Facades\Artisan::call('migrate',['--force'=>true]);
$checks=0;
function checkFix(string $name,bool $pass):void {global $checks;if(!$pass)throw new RuntimeException($name);$checks++;echo "PASS {$name}\n";}
$cases=[
 ['ASCII 8',str_repeat('a',8),true],['ASCII 71',str_repeat('b',71),true],
 ['ASCII 72',str_repeat('c',72),true],['ASCII 73',str_repeat('d',73),false],
 ['Arabic 8 characters',str_repeat('س',8),true],['Arabic 72 bytes',str_repeat('س',36),true],
 ['Arabic 74 bytes',str_repeat('س',37),false],['Short password',str_repeat('e',7),false],
];
foreach($cases as $i=>[$label,$password,$valid]) {
    $request=Illuminate\Http\Request::create('/signup','POST',['name'=>'Synthetic member','email'=>"fixture{$i}@example.test",'password'=>$password,'password_confirmation'=>$password]);
    $request->setLaravelSession($app['session']->driver());$app->instance('request',$request);
    Illuminate\Support\Facades\Auth::forgetGuards();
    $before=App\Models\User::count();$passed=false;$errors=[];
    try {(new App\Http\Controllers\SignupController)->store($request);$passed=true;}
    catch(Illuminate\Validation\ValidationException $e){$errors=$e->errors();}
    checkFix($label.' expected validation',$passed===$valid);
    checkFix($label.' account count',App\Models\User::count()===$before+($valid?1:0));
    if($valid) {
        $user=App\Models\User::where('email',"fixture{$i}@example.test")->firstOrFail();
        checkFix($label.' hash verification',Illuminate\Support\Facades\Hash::check($password,$user->password));
        checkFix($label.' bcrypt cost unchanged',password_get_info($user->password)['algoName']==='bcrypt' && password_get_info($user->password)['options']['cost']===12);
    } else {
        checkFix($label.' password field error',isset($errors['password']));
        if(strlen($password)>72)checkFix($label.' readable byte-limit error',in_array('Password must be 72 bytes or fewer. Please use a shorter password.',$errors['password'],true));
    }
    Illuminate\Support\Facades\Auth::logout();
}
$first=App\Models\User::where('email','fixture0@example.test')->firstOrFail();
checkFix('Existing valid account can authenticate',Illuminate\Support\Facades\Auth::attempt(['email'=>$first->email,'password'=>str_repeat('a',8)]));
echo "All {$checks} signup checks passed; production data was not used.\n";
