<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class HealthResource extends Model {
    protected $fillable=['title','organization','category','description','url','language'];
    public function safeUrl(): ?string {
        $host=strtolower((string) parse_url($this->url,PHP_URL_HOST));
        return parse_url($this->url,PHP_URL_SCHEME)==='https' && in_array($host,['www.moh.gov.sa','moh.gov.sa','www.pha.gov.sa','pha.gov.sa'],true) ? $this->url : null;
    }
}
