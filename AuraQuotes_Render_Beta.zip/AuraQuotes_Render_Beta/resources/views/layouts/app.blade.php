<!doctype html>
<html lang="en" dir="ltr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#0b1114">
<meta name="csrf-token" content="{{ csrf_token() }}"><title>@yield('title', 'Aura Quotes')</title>
<link rel="stylesheet" href="{{ asset('css/app.css') }}"><script src="{{ asset('js/app.js') }}" defer></script></head>
<body><a class="skip" href="#main">Skip to content</a><x-site-header /><main id="main"><x-alerts />@yield('content')</main><x-site-footer /></body></html>
