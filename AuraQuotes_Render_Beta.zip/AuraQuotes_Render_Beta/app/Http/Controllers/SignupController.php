<?php
namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class SignupController extends Controller {
 public function create() { return view('Authentication.SignUp'); }
 public function store(Request $r) {
    $r->merge(['email'=>strtolower(trim((string)$r->input('email','')))]);
    $data=$r->validate(['name'=>['required','string','min:2','max:50'],'email'=>['required','string','email:rfc','max:255','unique:users,email'],'password'=>['required','string','min:8','confirmed']]);
    $user=User::create(['name'=>$data['name'],'email'=>$data['email'],'password'=>$data['password']]);Auth::login($user);$r->session()->regenerate();
    return redirect()->route('quotes.index')->with('success','Welcome to Aura Quotes. Your account is ready.');
 }
}
