
<?php $__env->startSection('title', 'Your session needs a refresh. | Aura Quotes'); ?>
<?php $__env->startSection('content'); ?>
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">419</span><h1>Your session needs a refresh.</h1><p>Please reload the page and try again.</p><a class="button button-primary" href="<?php echo e(route('quotes.index')); ?>">Return to the library</a></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\errors\419.blade.php ENDPATH**/ ?>