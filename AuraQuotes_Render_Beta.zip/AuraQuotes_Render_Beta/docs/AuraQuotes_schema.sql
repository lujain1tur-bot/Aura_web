-- Schema reference; install with Laravel migrations.

CREATE TABLE "cache" ("key" varchar not null, "value" text not null, "expiration" integer not null, primary key ("key"));

CREATE TABLE "cache_locks" ("key" varchar not null, "owner" varchar not null, "expiration" integer not null, primary key ("key"));

CREATE TABLE "collection_items" ("id" integer primary key autoincrement not null, "collection_id" integer not null, "quote_id" integer not null, "created_at" datetime, "updated_at" datetime, foreign key("collection_id") references "collections"("id") on delete cascade, foreign key("quote_id") references "quotes"("id") on delete cascade);

CREATE TABLE "collections" ("id" integer primary key autoincrement not null, "user_id" integer not null, "name" varchar not null, "created_at" datetime, "updated_at" datetime, foreign key("user_id") references "users"("id") on delete cascade);

CREATE TABLE "failed_jobs" ("id" integer primary key autoincrement not null, "uuid" varchar not null, "connection" varchar not null, "queue" varchar not null, "payload" text not null, "exception" text not null, "failed_at" datetime not null default CURRENT_TIMESTAMP);

CREATE TABLE "health_resources" ("id" integer primary key autoincrement not null, "title" varchar not null, "organization" varchar not null, "category" varchar not null, "description" text not null, "url" varchar not null, "language" varchar not null default 'English', "created_at" datetime, "updated_at" datetime);

CREATE TABLE "job_batches" ("id" varchar not null, "name" varchar not null, "total_jobs" integer not null, "pending_jobs" integer not null, "failed_jobs" integer not null, "failed_job_ids" text not null, "options" text, "cancelled_at" integer, "created_at" integer not null, "finished_at" integer, primary key ("id"));

CREATE TABLE "jobs" ("id" integer primary key autoincrement not null, "queue" varchar not null, "payload" text not null, "attempts" integer not null, "reserved_at" integer, "available_at" integer not null, "created_at" integer not null);

CREATE TABLE "migrations" ("id" integer primary key autoincrement not null, "migration" varchar not null, "batch" integer not null);

CREATE TABLE "password_reset_tokens" ("email" varchar not null, "token" varchar not null, "created_at" datetime, primary key ("email"));

CREATE TABLE "quote_likes" ("id" integer primary key autoincrement not null, "user_id" integer not null, "quote_id" integer not null, "created_at" datetime, "updated_at" datetime, foreign key("user_id") references "users"("id") on delete cascade, foreign key("quote_id") references "quotes"("id") on delete cascade);

CREATE TABLE "quote_reports" ("id" integer primary key autoincrement not null, "user_id" integer, "quote_id" integer not null, "reason" varchar not null, "details" text, "status" varchar not null default 'open', "created_at" datetime, "updated_at" datetime, foreign key("user_id") references "users"("id") on delete set null, foreign key("quote_id") references "quotes"("id") on delete cascade);

CREATE TABLE "quote_saves" ("id" integer primary key autoincrement not null, "user_id" integer not null, "quote_id" integer not null, "created_at" datetime, "updated_at" datetime, foreign key("user_id") references "users"("id") on delete cascade, foreign key("quote_id") references "quotes"("id") on delete cascade);

CREATE TABLE "quotes" ("id" integer primary key autoincrement not null, "user_id" integer, "content" text not null, "category" varchar not null default ('عام'), "source_name" varchar, "source_type" varchar not null default ('user'), "is_verified" tinyint(1) not null default ('0'), "created_at" datetime, "updated_at" datetime, "source_url" varchar, foreign key("user_id") references "users"("id") on delete set null);

CREATE TABLE "sessions" ("id" varchar not null, "user_id" integer, "ip_address" varchar, "user_agent" text, "payload" text not null, "last_activity" integer not null, primary key ("id"));

CREATE TABLE "user_interests" ("id" integer primary key autoincrement not null, "user_id" integer not null, "category" varchar not null, "created_at" datetime, "updated_at" datetime, foreign key("user_id") references "users"("id") on delete cascade);

CREATE TABLE "users" ("id" integer primary key autoincrement not null, "name" varchar not null, "email" varchar not null, "email_verified_at" datetime, "password" varchar not null, "remember_token" varchar, "created_at" datetime, "updated_at" datetime);

CREATE INDEX "cache_expiration_index" on "cache" ("expiration");

CREATE INDEX "cache_locks_expiration_index" on "cache_locks" ("expiration");

CREATE UNIQUE INDEX "collection_items_collection_id_quote_id_unique" on "collection_items" ("collection_id", "quote_id");

CREATE UNIQUE INDEX "collections_user_id_name_unique" on "collections" ("user_id", "name");

CREATE INDEX "failed_jobs_connection_queue_failed_at_index" on "failed_jobs" ("connection", "queue", "failed_at");

CREATE UNIQUE INDEX "failed_jobs_uuid_unique" on "failed_jobs" ("uuid");

CREATE INDEX "health_resources_category_index" on "health_resources" ("category");

CREATE UNIQUE INDEX "health_resources_category_title_unique" on "health_resources" ("category", "title");

CREATE INDEX "jobs_queue_index" on "jobs" ("queue");

CREATE UNIQUE INDEX "quote_likes_user_id_quote_id_unique" on "quote_likes" ("user_id", "quote_id");

CREATE UNIQUE INDEX "quote_reports_user_id_quote_id_unique" on "quote_reports" ("user_id", "quote_id");

CREATE UNIQUE INDEX "quote_saves_user_id_quote_id_unique" on "quote_saves" ("user_id", "quote_id");

CREATE INDEX "quotes_category_date_index" on "quotes" ("category", "created_at", "id");

CREATE INDEX "sessions_last_activity_index" on "sessions" ("last_activity");

CREATE INDEX "sessions_user_id_index" on "sessions" ("user_id");

CREATE UNIQUE INDEX "user_interests_user_id_category_unique" on "user_interests" ("user_id", "category");

CREATE UNIQUE INDEX "users_email_unique" on "users" ("email");