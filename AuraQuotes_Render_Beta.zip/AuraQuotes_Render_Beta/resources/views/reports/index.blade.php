@extends('layouts.app')
@section('title', 'Your reports | Aura Quotes')
@section('content')
<section class="wrap content-page"><div class="page-heading"><span class="eyebrow">YOUR PRIVATE SUBMISSIONS</span><h1>Your reports.</h1><p>A record of the concerns you submitted. Reports remain open; submission does not remove content automatically.</p></div><div class="report-list">@forelse($reports as $report)<article class="panel report-card"><div class="result-bar"><strong>{{ $report->reason }}</strong><span class="tag">{{ ucfirst($report->status) }}</span></div><blockquote>{{ $report->quote?->content }}</blockquote>@if($report->details)<p>{{ $report->details }}</p>@endif<small class="muted">Submitted {{ $report->created_at->format('M j, Y') }}</small></article>@empty<div class="panel empty-state"><h2>No reports submitted.</h2><p>You can report a quote from its card in the library.</p></div>@endforelse</div><x-pagination :paginator="$reports" /></section>
@endsection
