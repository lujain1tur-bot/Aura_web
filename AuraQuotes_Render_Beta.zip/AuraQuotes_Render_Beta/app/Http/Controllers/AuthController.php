<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class AuthController extends Controller {
 public function showLogin() { return view('Authentication.LogIn'); }
 public function login(Request $r) {
    $r->merge(['email'=>strtolower(trim((string)$r->input('email','')))]);
    $credentials=$r->validate(['email'=>['required','email'],'password'=>['required','string']]);
    if(!Auth::attempt($credentials,$r->boolean('remember'))){return back()->withErrors(['email'=>'The email or password is incorrect.'])->onlyInput('email');}
    $r->session()->regenerate();return redirect()->intended(route('quotes.index'))->with('success','You are now logged in.');
 }
 public function logout(Request $r) { Auth::logout();$r->session()->invalidate();$r->session()->regenerateToken();return redirect()->route('quotes.index')->with('success','You have been logged out.'); }
}
