# AuraQuotes Mermaid ERD

Logical types are engine-neutral. Actual migrations define SQLite and PostgreSQL physical types. Lines represent declared foreign keys only. Composite unique keys are recorded in comments and the PDF.

```mermaid
erDiagram
    quotes ||--o{ collection_items : "quote_id"
    collections ||--o{ collection_items : "collection_id"
    users ||--o{ collections : "user_id"
    quotes ||--o{ quote_likes : "quote_id"
    users ||--o{ quote_likes : "user_id"
    quotes ||--o{ quote_reports : "quote_id"
    users |o--o{ quote_reports : "user_id"
    quotes ||--o{ quote_saves : "quote_id"
    users ||--o{ quote_saves : "user_id"
    users |o--o{ quotes : "user_id"
    users ||--o{ user_interests : "user_id"

    cache {
        string key PK "required"
        text value "required"
        integer expiration "required"
    }

    cache_locks {
        string key PK "required"
        string owner "required"
        integer expiration "required"
    }

    collection_items {
        integer id PK "required"
        integer collection_id FK "required"
        integer quote_id FK "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    collections {
        integer id PK "required"
        integer user_id FK "required"
        string name "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    failed_jobs {
        integer id PK "required"
        string uuid UK "required"
        string connection "required"
        string queue "required"
        text payload "required"
        text exception "required"
        datetime failed_at "required"
    }

    health_resources {
        integer id PK "required"
        string title "required"
        string organization "required"
        string category "required"
        text description "required"
        string url "required"
        string language "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    job_batches {
        string id PK "required"
        string name "required"
        integer total_jobs "required"
        integer pending_jobs "required"
        integer failed_jobs "required"
        text failed_job_ids "required"
        text options "nullable"
        integer cancelled_at "nullable"
        integer created_at "required"
        integer finished_at "nullable"
    }

    jobs {
        integer id PK "required"
        string queue "required"
        text payload "required"
        integer attempts "required"
        integer reserved_at "nullable"
        integer available_at "required"
        integer created_at "required"
    }

    migrations {
        integer id PK "required"
        string migration "required"
        integer batch "required"
    }

    password_reset_tokens {
        string email PK "required"
        string token "required"
        datetime created_at "nullable"
    }

    quote_likes {
        integer id PK "required"
        integer user_id FK "required"
        integer quote_id FK "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    quote_reports {
        integer id PK "required"
        integer user_id FK "nullable"
        integer quote_id FK "required"
        string reason "required"
        text details "nullable"
        string status "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    quote_saves {
        integer id PK "required"
        integer user_id FK "required"
        integer quote_id FK "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    quotes {
        integer id PK "required"
        integer user_id FK "nullable"
        text content "required"
        string category "required"
        string source_name "nullable"
        string source_type "required"
        boolean is_verified "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
        string source_url "nullable"
    }

    sessions {
        string id PK "required"
        integer user_id "nullable"
        string ip_address "nullable"
        text user_agent "nullable"
        text payload "required"
        integer last_activity "required"
    }

    user_interests {
        integer id PK "required"
        integer user_id FK "required"
        string category "required"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }

    users {
        integer id PK "required"
        string name "required"
        string email UK "required"
        datetime email_verified_at "nullable"
        string password "required"
        string remember_token "nullable"
        datetime created_at "nullable"
        datetime updated_at "nullable"
    }
    %% collection_items: UNIQUE(collection_id, quote_id)
    %% collections: UNIQUE(user_id, name)
    %% health_resources: UNIQUE(category, title)
    %% quote_likes: UNIQUE(user_id, quote_id)
    %% quote_reports: UNIQUE(user_id, quote_id)
    %% quote_saves: UNIQUE(user_id, quote_id)
    %% user_interests: UNIQUE(user_id, category)
```
