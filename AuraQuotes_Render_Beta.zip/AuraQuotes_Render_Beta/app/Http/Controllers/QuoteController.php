<?php
namespace App\Http\Controllers;
use App\Models\Quote;
use App\Models\HealthResource;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
class QuoteController extends Controller {
 public function index(Request $request) {
    $request->validate(['q'=>['nullable','string','max:200'],'category'=>['nullable',Rule::in(Quote::CATEGORIES)],'feed'=>['nullable',Rule::in(['all','for-you'])]]);
    $query=Quote::with('user:id,name')->withCount('likes');
    $search=trim((string)$request->query('q',''));
    if($search!==''){$query->where(fn($q)=>$q->whereLike('content',"%{$search}%")->orWhereLike('source_name',"%{$search}%")->orWhereLike('category',"%{$search}%"));}
    if($category=$request->query('category')){$query->where('category',$category);}
    if($request->boolean('saved') && $request->user()){$query->whereHas('savers',fn($q)=>$q->where('users.id',$request->user()->id));}
    $interests=$request->user() ? $request->user()->interests()->pluck('category')->all() : [];
    if($interests && $request->query('feed','for-you')==='for-you') {
        $query->orderByRaw('case when category in ('.implode(',',array_fill(0,count($interests),'?')).') then 0 else 1 end',$interests);
    }
    $quotes=$query->latest()->orderByDesc('id')->paginate(12)->withQueryString();
    $ids=$quotes->modelKeys();
    $likedIds=$request->user() ? $request->user()->likedQuotes()->whereIn('quotes.id',$ids)->pluck('quotes.id')->all() : [];
    $savedIds=$request->user() ? $request->user()->savedQuotes()->whereIn('quotes.id',$ids)->pluck('quotes.id')->all() : [];
    $resourceCategories=Cache::remember('aura.resource.categories',3600,fn()=>HealthResource::distinct()->pluck('category')->all());
    return view('index',compact('quotes','likedIds','savedIds','interests','resourceCategories'));
 }
 private function validated(Request $r): array { return $r->validate(['content'=>['required','string','min:3','max:155'],'category'=>['required',Rule::in(Quote::CATEGORIES)],'source_name'=>['nullable','string','max:120']]); }
 public function store(Request $r) { $r->user()->quotes()->create($this->validated($r)+['source_type'=>'user','is_verified'=>false]);return redirect()->route('quotes.index')->with('success','Your quote has been published.'); }
 public function edit(Quote $quote) { $this->owner($quote);return view('quotes.edit',compact('quote')); }
 public function update(Request $r,Quote $quote) { $this->owner($quote);$quote->update($this->validated($r));return redirect()->route('quotes.index')->with('success','Your quote has been updated.'); }
 public function destroy(Quote $quote) { $this->owner($quote);$quote->delete();return redirect()->route('quotes.index')->with('success','Your quote has been deleted.'); }
 public function toggleLike(Request $r,Quote $quote) { $r->user()->likedQuotes()->toggle($quote->id);return back()->with('success','Your like has been updated.'); }
 public function toggleSave(Request $r,Quote $quote) {
    DB::transaction(function()use($r,$quote){
        $result=$r->user()->savedQuotes()->toggle($quote->id);
        if($result['detached']){DB::table('collection_items')->where('quote_id',$quote->id)->whereIn('collection_id',$r->user()->collections()->select('id'))->delete();}
    });return back()->with('success','Your saved quotes have been updated.');
 }
 private function owner(Quote $quote): void { abort_unless($quote->user_id!==null && $quote->user_id===auth()->id(),403,'Only the publisher can change this quote.'); }
}
