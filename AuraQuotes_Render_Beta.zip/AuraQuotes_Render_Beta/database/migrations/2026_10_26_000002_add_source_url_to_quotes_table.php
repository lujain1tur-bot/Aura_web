<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void { Schema::table('quotes', function (Blueprint $table) { $table->string('source_url', 2048)->nullable()->after('source_name'); }); }
    public function down(): void { Schema::table('quotes', function (Blueprint $table) { $table->dropColumn('source_url'); }); }
};
