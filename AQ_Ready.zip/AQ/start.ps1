param([switch]$SetupOnly, [switch]$NoBrowser, [int]$Port = 8000)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

$candidates = @()
$phpCommand = Get-Command php -ErrorAction SilentlyContinue
if ($phpCommand) { $candidates += $phpCommand.Source }
$herdRoot = Join-Path $env:USERPROFILE '.config\herd\bin'
if (Test-Path -LiteralPath $herdRoot) {
    $candidates += Get-ChildItem -LiteralPath $herdRoot -Directory -Filter 'php*' |
        Sort-Object Name -Descending |
        ForEach-Object { Join-Path $_.FullName 'php.exe' } |
        Where-Object { Test-Path -LiteralPath $_ }
}
$phpBinary = $null
foreach ($candidate in ($candidates | Select-Object -Unique)) {
    try {
        $versionText = (& $candidate -r 'echo PHP_VERSION_ID;' 2>$null | Out-String).Trim()
        if ($versionText -match '^\d+$' -and [int]$versionText -ge 80401) {
            $phpBinary = $candidate
            break
        }
    } catch { }
}
if (-not $phpBinary) { throw 'PHP 8.4.1 or later was not found. Select PHP 8.5 in Laravel Herd.' }
if (-not (Test-Path -LiteralPath 'vendor/autoload.php')) { throw 'Extract the complete AQ folder first, then run START-AURA.cmd inside it.' }

& $phpBinary 'scripts/setup.php'
if ($LASTEXITCODE -ne 0) { throw 'Application setup did not complete. See the message above.' }
if ($SetupOnly) { exit 0 }
if ($Port -lt 1 -or $Port -gt 65515) { throw 'Choose a port from 1 to 65515.' }

function Test-AvailablePort([int]$CandidatePort) {
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $CandidatePort)
    try { $listener.Start(); return $true } catch { return $false } finally { $listener.Stop() }
}
$selectedPort = $Port
while (-not (Test-AvailablePort $selectedPort)) {
    $selectedPort++
    if ($selectedPort -ge $Port + 20) { throw 'No free local port was found. Close an unused local server and try again.' }
}
$localUrl = "http://127.0.0.1:$selectedPort"
Write-Host ''
Write-Host "AuraQuotes is ready: $localUrl" -ForegroundColor Green
Write-Host 'Keep this window open while using the site. Press Ctrl+C to stop.'
if ($selectedPort -ne $Port) { Write-Host "Port $Port is already in use. This copy will use $selectedPort." }

$browserJob = $null
if (-not $NoBrowser) {
    $browserJob = Start-Job -ArgumentList $localUrl -ScriptBlock {
        param($url)
        for ($attempt = 0; $attempt -lt 45; $attempt++) {
            try {
                $null = Invoke-WebRequest -Uri "$url/up" -UseBasicParsing -TimeoutSec 2
                Start-Process $url
                break
            } catch { Start-Sleep -Milliseconds 400 }
        }
    }
}
try {
    & $phpBinary artisan serve --host=127.0.0.1 --port=$selectedPort
    if ($LASTEXITCODE -ne 0) { throw 'The local server stopped unexpectedly. See the message above.' }
} finally {
    if ($browserJob) {
        Stop-Job -Job $browserJob -ErrorAction SilentlyContinue
        Remove-Job -Job $browserJob -Force -ErrorAction SilentlyContinue
    }
}
