<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
class SecurityHeaders {
 public function handle(Request $request,Closure $next) {
    $response=$next($request);
    $response->headers->set('X-Content-Type-Options','nosniff');
    $response->headers->set('X-Frame-Options','DENY');
    $response->headers->set('Referrer-Policy','strict-origin-when-cross-origin');
    $response->headers->set('Content-Security-Policy',"default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
    return $response;
 }
}
