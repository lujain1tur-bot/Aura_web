
<?php $__env->startSection('title','Aura Quotes · A little more perspective'); ?>
<?php $__env->startSection('content'); ?>
<section class="hero wrap"><div class="hero-copy"><span class="eyebrow"><span class="status-dot"></span> A mindful corner of the internet</span><h1>Small words.<br><em>A healthier<br>perspective.</em></h1><p>Explore thoughtful words on health and everyday life. Keep what resonates, share what matters, and find trusted places to learn more.</p><div class="button-row"><a class="button button-primary" href="#library">Explore the library <span aria-hidden="true">↓</span></a><a class="text-link" href="<?php echo e(route('resources.index')); ?>">Official health resources ↗</a></div><div class="hero-note"><span class="mini-star" aria-hidden="true">✳</span><span>A moment to pause.<br><strong>Something worth keeping.</strong></span></div></div>
<div class="hero-visual"><div class="orb orb-one"></div><div class="orb orb-two"></div><div class="featured-card"><div class="featured-top"><span>THE AURA PERSPECTIVE</span><span aria-hidden="true">✳</span></div><blockquote>One small, realistic step today is better than an endlessly postponed perfect plan.</blockquote><div class="featured-bottom"><span class="tag">Mental wellbeing</span><span>Aura Quotes</span></div></div><div class="floating-note"><span aria-hidden="true">↗</span> Take what helps. Return when you need.</div></div></section>
<?php if(auth()->guard()->check()): ?><section class="wrap publish-section" id="share"><details class="panel publish-panel" <?php if($errors->hasAny(['content','category','source_name'])): ?> open <?php endif; ?>><summary><span><span class="eyebrow">YOUR WORDS MATTER</span><strong>Share a little perspective</strong></span><span class="summary-plus" aria-hidden="true">+</span></summary><form action="<?php echo e(route('quotes.store')); ?>" method="POST" class="publish-form"><?php echo csrf_field(); ?>
<?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['id' => 'content','label' => 'Your quote','hint' => '3–155 characters. Text only.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'content','label' => 'Your quote','hint' => '3–155 characters. Text only.']); ?><textarea id="content" name="content" required minlength="3" maxlength="155" placeholder="A thought worth sharing…"><?php echo e(old('content')); ?></textarea> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?><div class="form-columns"><?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['id' => 'category','label' => 'Category','hint' => 'Choose a topic for your quote.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'category','label' => 'Category','hint' => 'Choose a topic for your quote.']); ?><select id="category" name="category" required><option value="">Select a category</option><?php $__currentLoopData = \App\Models\Quote::CATEGORIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($cat); ?>" <?php if(old('category')===$cat): echo 'selected'; endif; ?>><?php echo e($cat); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?><?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['id' => 'source_name','label' => 'Author or source','hint' => 'Optional. Up to 120 characters.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'source_name','label' => 'Author or source','hint' => 'Optional. Up to 120 characters.']); ?><input id="source_name" name="source_name" value="<?php echo e(old('source_name')); ?>" maxlength="120" placeholder="Author name"> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?></div><button class="button button-primary" type="submit">Publish quote ↗</button></form></details></section><?php endif; ?>
<section class="library-section" id="library"><div class="wrap"><div class="section-heading"><div><span class="eyebrow">THE LIBRARY</span><h2>Find a thought to keep.</h2><p class="muted">A collection of words for everyday wellbeing.</p></div><?php if(auth()->guard()->check()): ?><a class="button" href="<?php echo e(route('quotes.index',['saved'=>1])); ?>">My saved quotes ↗</a><?php endif; ?></div>
<form method="GET" action="<?php echo e(route('quotes.index')); ?>" class="search-form"><label class="search-field"><span aria-hidden="true">⌕</span><span class="sr-only">Search quotes</span><input type="search" name="q" value="<?php echo e(request('q')); ?>" maxlength="200" placeholder="Search words, authors or topics…"></label><?php $__currentLoopData = ['category','saved','feed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(request($key)): ?><input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e(request($key)); ?>"><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><button class="button button-primary" type="submit">Search</button></form>
<div class="filters" aria-label="Category filters"><a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['chip','selected'=>!request('category')]); ?>" href="<?php echo e(route('quotes.index',request()->except('category','page'))); ?>">All topics</a><?php $__currentLoopData = \App\Models\Quote::CATEGORIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['chip','selected'=>request('category')===$cat]); ?>" href="<?php echo e(route('quotes.index',array_merge(request()->except('page'),['category'=>$cat]))); ?>"><?php echo e($cat); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
<div class="result-bar"><span><?php echo e($quotes->total()); ?> <?php echo e(Str::plural('quote',$quotes->total())); ?><?php if(request('saved')): ?> · My saved quotes <?php endif; ?></span><div class="feed-controls"><?php if(auth()->guard()->check()): ?> <?php if($interests): ?><a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected-text'=>request('feed','for-you')==='for-you']); ?>" href="<?php echo e(route('quotes.index',array_merge(request()->except('page'),['feed'=>'for-you']))); ?>">For you</a><a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected-text'=>request('feed')==='all']); ?>" href="<?php echo e(route('quotes.index',array_merge(request()->except('page'),['feed'=>'all']))); ?>">Newest</a><?php else: ?><a href="<?php echo e(route('interests.edit')); ?>">Choose your interests ↗</a><?php endif; ?> <?php endif; ?> <?php if(request()->hasAny(['q','category','saved','feed'])): ?><a href="<?php echo e(route('quotes.index',['feed'=>'all'])); ?>">Clear filters</a><?php endif; ?></div></div>
<div class="quote-grid"><?php $__empty_1 = true; $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if (isset($component)) { $__componentOriginalff301bacf4984f77aa4bdcc81ca58cab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff301bacf4984f77aa4bdcc81ca58cab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quote-card','data' => ['quote' => $quote,'likedIds' => $likedIds,'savedIds' => $savedIds,'resourceCategories' => $resourceCategories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quote-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['quote' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quote),'liked-ids' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($likedIds),'saved-ids' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($savedIds),'resource-categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resourceCategories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff301bacf4984f77aa4bdcc81ca58cab)): ?>
<?php $attributes = $__attributesOriginalff301bacf4984f77aa4bdcc81ca58cab; ?>
<?php unset($__attributesOriginalff301bacf4984f77aa4bdcc81ca58cab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff301bacf4984f77aa4bdcc81ca58cab)): ?>
<?php $component = $__componentOriginalff301bacf4984f77aa4bdcc81ca58cab; ?>
<?php unset($__componentOriginalff301bacf4984f77aa4bdcc81ca58cab); ?>
<?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state"><span aria-hidden="true">✳</span><h3>No quotes here yet.</h3><p>Try another search or topic, or save a quote to start your collection.</p><a class="button" href="<?php echo e(route('quotes.index')); ?>">Back to the library</a></div><?php endif; ?></div><?php if (isset($component)) { $__componentOriginal41032d87daf360242eb88dbda6c75ed1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41032d87daf360242eb88dbda6c75ed1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination','data' => ['paginator' => $quotes]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($quotes)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $attributes = $__attributesOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $component = $__componentOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__componentOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?></div></section>
<section class="wrap resource-banner"><div><span class="eyebrow">KEEP EXPLORING</span><h2>A thought starts here.<br>The learning goes further.</h2><p>Explore official resources from the Saudi Ministry of Health and Weqaya.</p></div><a class="button button-primary" href="<?php echo e(route('resources.index')); ?>">Visit health resources ↗</a></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\index.blade.php ENDPATH**/ ?>