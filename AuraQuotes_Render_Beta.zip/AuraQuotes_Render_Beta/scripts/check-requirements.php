<?php
if (PHP_VERSION_ID < 80401) {
    fwrite(STDERR, "PHP 8.4.1 or later is required. Select PHP 8.5 in Laravel Herd.\n");
    exit(1);
}
foreach (['pdo_sqlite', 'mbstring', 'openssl', 'fileinfo', 'dom', 'xml', 'ctype', 'tokenizer', 'session', 'filter'] as $extension) {
    if (!extension_loaded($extension)) {
        fwrite(STDERR, "Missing PHP extension: {$extension}\n");
        exit(1);
    }
}
echo "PHP requirements passed.\n";
