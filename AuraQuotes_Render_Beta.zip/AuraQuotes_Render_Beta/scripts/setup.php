<?php
require __DIR__.'/check-requirements.php';
chdir(dirname(__DIR__));
if (!is_file('vendor/autoload.php')) {
    fwrite(STDERR, "Run composer install to restore vendor first.\n");
    exit(1);
}
if (!is_file('.env')) { copy('.env.example', '.env'); }
if (!is_file('database/database.sqlite')) { touch('database/database.sqlite'); }
foreach (['storage/framework/cache/data', 'storage/framework/sessions', 'storage/framework/views', 'storage/logs', 'bootstrap/cache'] as $directory) {
    if (!is_dir($directory)) { mkdir($directory, 0755, true); }
}
$commands = [['config:clear']];
if (preg_match('/^APP_KEY=\s*$/m', file_get_contents('.env'))) { $commands[] = ['key:generate', '--force']; }
$commands[] = ['migrate', '--force'];
$commands[] = ['db:seed', '--force'];
$commands[] = ['view:cache'];
foreach ($commands as $arguments) {
    $process = proc_open([PHP_BINARY, 'artisan', ...$arguments], [0=>STDIN, 1=>STDOUT, 2=>STDERR], $pipes);
    if (!is_resource($process) || proc_close($process) !== 0) { exit(1); }
}
echo "Ready. Run php artisan serve and open http://127.0.0.1:8000\n";
