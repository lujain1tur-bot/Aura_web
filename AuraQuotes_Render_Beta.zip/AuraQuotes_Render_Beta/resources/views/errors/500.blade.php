@extends('layouts.app')
@section('title', 'Something needs a moment. | Aura Quotes')
@section('content')
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">500</span><h1>Something needs a moment.</h1><p>We could not complete the request. Please try again shortly.</p><a class="button button-primary" href="{{ route('quotes.index') }}">Return to the library</a></div></section>
@endsection
