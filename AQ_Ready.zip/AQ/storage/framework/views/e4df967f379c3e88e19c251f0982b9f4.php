
<?php $__env->startSection('title', 'Health resources | Aura Quotes'); ?>
<?php $__env->startSection('content'); ?>
<section class="wrap content-page"><div class="page-heading"><span class="eyebrow">TRUSTED PLACES TO LEARN</span><h1>Health resources.</h1><p>Continue your reading with official health organizations. Each link takes you directly to the original website.</p></div><form method="GET" action="<?php echo e(route('resources.index')); ?>" class="search-form"><label class="search-field"><span class="sr-only">Search resources</span><input type="search" name="q" value="<?php echo e(request('q')); ?>" maxlength="200" placeholder="Search resources or organizations…"></label><label class="sr-only" for="resource-category">Topic</label><select name="category" id="resource-category"><option value="">All topics</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option <?php if(request('category')===$cat): echo 'selected'; endif; ?>><?php echo e($cat); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><button class="button button-primary">Find resources</button></form><?php if(request()->hasAny(['q','category'])): ?><p><a class="text-link" href="<?php echo e(route('resources.index')); ?>">Clear filters</a></p><?php endif; ?>
<div class="resource-grid"><?php $__empty_1 = true; $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><article class="panel resource-card"><div class="resource-icon" aria-hidden="true">↗</div><span class="eyebrow"><?php echo e($resource->organization); ?></span><h2><?php echo e($resource->title); ?></h2><p><?php echo e($resource->description); ?></p><div class="resource-tags"><span class="tag"><?php echo e($resource->category); ?></span><span class="muted"><?php echo e($resource->language); ?></span></div><?php if($resource->safeUrl()): ?><a class="button" href="<?php echo e($resource->safeUrl()); ?>" target="_blank" rel="noopener noreferrer">Visit official source ↗</a><?php endif; ?></article><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state"><h2>No matching resources.</h2><p>Try another topic or clear the search.</p></div><?php endif; ?></div><?php if (isset($component)) { $__componentOriginal41032d87daf360242eb88dbda6c75ed1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41032d87daf360242eb88dbda6c75ed1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination','data' => ['paginator' => $resources]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resources)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $attributes = $__attributesOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $component = $__componentOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__componentOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\resources\index.blade.php ENDPATH**/ ?>