<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('quotes') && Schema::hasColumn('quotes', 'user_id')) {
            Schema::table('quotes', function (Blueprint $table) {
                $table->foreignId('user_id')->nullable()->change();
            });
        }
        Schema::create('quote_likes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('quote_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['user_id', 'quote_id']);
        });
        Schema::create('quote_saves', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('quote_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['user_id', 'quote_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('quote_saves');
        Schema::dropIfExists('quote_likes');
    }
};
