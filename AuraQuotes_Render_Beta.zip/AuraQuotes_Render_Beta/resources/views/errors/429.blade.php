@extends('layouts.app')
@section('title', 'Take a short pause. | Aura Quotes')
@section('content')
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">429</span><h1>Take a short pause.</h1><p>Too many requests. Please wait a minute and try again.</p><a class="button button-primary" href="{{ route('quotes.index') }}">Return to the library</a></div></section>
@endsection
