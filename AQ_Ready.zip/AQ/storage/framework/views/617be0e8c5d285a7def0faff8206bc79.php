<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['paginator']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['paginator']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?><?php if($paginator->hasPages()): ?><nav class="page-nav" aria-label="Result pages"><?php if($paginator->onFirstPage()): ?><span class="button disabled" aria-disabled="true">← Previous</span><?php else: ?><a class="button" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">← Previous</a><?php endif; ?><span>Page <?php echo e($paginator->currentPage()); ?> of <?php echo e($paginator->lastPage()); ?></span><?php if($paginator->hasMorePages()): ?><a class="button" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Next →</a><?php else: ?><span class="button disabled" aria-disabled="true">Next →</span><?php endif; ?></nav><?php endif; ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\components\pagination.blade.php ENDPATH**/ ?>