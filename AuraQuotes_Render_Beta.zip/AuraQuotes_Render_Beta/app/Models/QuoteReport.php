<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class QuoteReport extends Model {
    public const REASONS=['Potentially inaccurate health information','Inappropriate or harmful content','Other'];
    protected $fillable=['quote_id','reason','details','status'];
    public function quote() { return $this->belongsTo(Quote::class); }
    public function user() { return $this->belongsTo(User::class); }
}
