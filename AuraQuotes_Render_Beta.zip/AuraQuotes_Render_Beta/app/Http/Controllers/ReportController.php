<?php
namespace App\Http\Controllers;
use App\Models\Quote;
use App\Models\QuoteReport;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
class ReportController extends Controller {
 public function create(Quote $quote) { return view('reports.create',compact('quote')); }
 public function store(Request $r,Quote $quote) {
    $data=$r->validate(['reason'=>['required',Rule::in(QuoteReport::REASONS)],'details'=>['nullable','string','max:1000']]);
    $r->user()->reports()->firstOrCreate(['quote_id'=>$quote->id],$data+['status'=>'open']);
    return redirect()->route('reports.index')->with('success','Your report has been recorded. Reporting does not remove a quote automatically.');
 }
 public function index(Request $r) { $reports=$r->user()->reports()->with('quote:id,content')->latest()->paginate(12);return view('reports.index',compact('reports')); }
}
