<?php
namespace App\Http\Controllers;
use App\Models\Quote;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
class InterestController extends Controller {
 public function edit(Request $r) { $selected=$r->user()->interests()->pluck('category')->all();return view('interests.edit',compact('selected')); }
 public function update(Request $r) {
    $data=$r->validate(['categories'=>['sometimes','array','max:17'],'categories.*'=>['required','string','distinct',Rule::in(Quote::CATEGORIES)]]);
    DB::transaction(function()use($r,$data){$r->user()->interests()->delete();foreach($data['categories']??[] as $category){$r->user()->interests()->create(['category'=>$category]);}});
    return redirect()->route('quotes.index',['feed'=>'for-you'])->with('success','Your interests have been saved.');
 }
}
