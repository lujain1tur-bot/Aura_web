
<?php $__env->startSection('title', 'A little off the path. | Aura Quotes'); ?>
<?php $__env->startSection('content'); ?>
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">404</span><h1>A little off the path.</h1><p>This page or item could not be found.</p><a class="button button-primary" href="<?php echo e(route('quotes.index')); ?>">Return to the library</a></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\errors\404.blade.php ENDPATH**/ ?>