
<?php $__env->startSection('title', 'Something needs a moment. | Aura Quotes'); ?>
<?php $__env->startSection('content'); ?>
<section class="wrap content-page"><div class="empty-state"><span class="eyebrow">500</span><h1>Something needs a moment.</h1><p>We could not complete the request. Please try again shortly.</p><a class="button button-primary" href="<?php echo e(route('quotes.index')); ?>">Return to the library</a></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lujain\Downloads\AQ\resources\views\errors\500.blade.php ENDPATH**/ ?>