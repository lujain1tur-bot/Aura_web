<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Quote extends Model {
    use HasFactory;
    public const CATEGORIES = ['General', 'Life', 'Success', 'Wisdom', 'Happiness', 'Motivation', 'Asthma', 'Nutrition', 'Physical activity', 'Sleep', 'Mental wellbeing', 'Prevention', 'Diabetes', 'Blood pressure', 'Smoking', 'Oral health', 'Family health'];
    protected $fillable = ['user_id','content','category','source_name','source_url','source_type','is_verified'];
    public function user() { return $this->belongsTo(User::class); }
    public function likes() { return $this->belongsToMany(User::class,'quote_likes')->withTimestamps(); }
    public function savers() { return $this->belongsToMany(User::class,'quote_saves')->withTimestamps(); }
    public function collections() { return $this->belongsToMany(QuoteCollection::class,'collection_items','quote_id','collection_id')->withTimestamps(); }
    public function sourceLink(): ?string {
        return in_array(parse_url($this->source_url ?? '',PHP_URL_SCHEME),['https','http'],true) ? $this->source_url : null;
    }
}
