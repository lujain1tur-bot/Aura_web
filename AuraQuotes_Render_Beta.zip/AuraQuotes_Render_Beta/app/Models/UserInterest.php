<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class UserInterest extends Model {
    protected $fillable=['category']; public function user() { return $this->belongsTo(User::class); }
}
